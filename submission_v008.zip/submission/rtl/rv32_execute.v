// RV32I combinational execution. Architectural writes happen only at retirement.
module rv32_execute #(parameter ZMMUL=0)(
    input wire [31:0] insn, pc, a, b,
    output wire [4:0] rs1, rs2, rd,
    output reg use_rs1, use_rs2, write_rd, load, store, system,
    output reg [31:0] result, next_pc, address, store_data,
    output reg [3:0] strobe,
    output reg trap,
    output reg [31:0] cause, tval
);
    wire [6:0] op=insn[6:0];
    wire [2:0] f3=insn[14:12];
    wire [6:0] f7=insn[31:25];
    wire [31:0] ii={{20{insn[31]}},insn[31:20]};
    wire [31:0] si={{20{insn[31]}},insn[31:25],insn[11:7]};
    wire [31:0] bi={{19{insn[31]}},insn[31],insn[7],insn[30:25],insn[11:8],1'b0};
    wire [31:0] ji={{11{insn[31]}},insn[31],insn[19:12],insn[20],insn[30:21],1'b0};
    wire [31:0] ui={insn[31:12],12'b0};
    reg [31:0] rhs;
    reg take_branch;
    assign rs1=insn[19:15]; assign rs2=insn[24:20]; assign rd=insn[11:7];
    always @* begin
        use_rs1=0; use_rs2=0; write_rd=0; load=0; store=0; system=0;
        result=0; next_pc=pc+4; address=0; store_data=0; strobe=0;
        trap=0; cause=2; tval=insn; rhs=b; take_branch=0;
        case(op)
            7'h37: begin write_rd=1; result=ui; end
            7'h17: begin write_rd=1; result=pc+ui; end
            7'h6f: begin write_rd=1; result=pc+4; next_pc=pc+ji; end
            7'h67: begin
                use_rs1=1; write_rd=1; result=pc+4; next_pc=(a+ii)&32'hfffffffe;
                if(f3!=0) trap=1;
            end
            7'h63: begin
                use_rs1=1; use_rs2=1;
                case(f3)
                    0: take_branch=(a==b); 1: take_branch=(a!=b);
                    4: take_branch=($signed(a)<$signed(b));
                    5: take_branch=($signed(a)>=$signed(b));
                    6: take_branch=(a<b); 7: take_branch=(a>=b);
                    default: trap=1;
                endcase
                if(take_branch) next_pc=pc+bi;
            end
            7'h13,7'h33: begin
                use_rs1=1; write_rd=1;
                if(op==7'h13) rhs=ii; else use_rs2=1;
                case(f3)
                    0: begin
                        if(op==7'h33 && f7==7'h20) result=a-b; else result=a+rhs;
                        if(op==7'h33 && f7!=0 && f7!=7'h20) trap=1;
                    end
                    1: begin result=a<<rhs[4:0]; if(f7!=0) trap=1; end
                    2: begin result={31'b0,$signed(a)<$signed(rhs)}; if(op==7'h33 && f7!=0) trap=1; end
                    3: begin result={31'b0,a<rhs}; if(op==7'h33 && f7!=0) trap=1; end
                    4: begin result=a^rhs; if(op==7'h33 && f7!=0) trap=1; end
                    5: begin
                        if(f7==7'h20) result=$signed(a)>>>rhs[4:0]; else result=a>>rhs[4:0];
                        if(f7!=0 && f7!=7'h20) trap=1;
                    end
                    6: begin result=a|rhs; if(op==7'h33 && f7!=0) trap=1; end
                    7: begin result=a&rhs; if(op==7'h33 && f7!=0) trap=1; end
                endcase
                // Multicycle DSP result is supplied by the pipeline. Division
                // and remainder encodings still raise illegal instruction.
                if(ZMMUL && op==7'h33 && f7==1 && f3<4) begin
                    trap=0;result=0;
                end
            end
            7'h03,7'h23: begin
                use_rs1=1; load=(op==7'h03); store=!load; use_rs2=store; write_rd=load;
                address=a+(load?ii:si); store_data=b<<(address[1:0]*8);
                case(f3)
                    0: strobe=4'b0001<<address[1:0];
                    1: strobe=4'b0011<<address[1:0];
                    2: strobe=4'b1111;
                    4: if(!load) trap=1;
                    5: if(!load) trap=1;
                    default: trap=1;
                endcase
                if(!trap && (((f3==1 || f3==5) && address[0]) || (f3==2 && address[1:0]!=0))) begin
                    trap=1; cause=load?4:6; tval=address;
                end
            end
            7'h0f: begin // Single hart, serialized stores: ordinary FENCE is an ordering no-op.
                if(f3!=0 || insn[31:28]!=0) trap=1;
            end
            7'h73: begin
                system=1;
                if(f3!=0) begin
                    write_rd=1; use_rs1=!f3[2];
                    if(f3==4) trap=1;
                end else if(insn!=32'h00000073 && insn!=32'h00100073 &&
                            insn!=32'h30200073 && insn!=32'h10500073) trap=1;
            end
            default: trap=1;
        endcase
        if(!trap && next_pc[1:0]!=0) begin trap=1; cause=0; tval=next_pc; end
    end
endmodule
