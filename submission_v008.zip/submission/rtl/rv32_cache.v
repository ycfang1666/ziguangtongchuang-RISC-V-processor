// Blocking 2 KiB, two-way cache, 16-byte lines, true LRU (one bit/set).
// Data policy: write-through / no-write-allocate. MMIO never allocates.
module rv32_cache #(parameter ENABLE=1, parameter READ_ONLY=0, parameter FAST_HIT=1, parameter COUNT_PIPE=1, parameter LRU_PIPE=1, parameter POST_RAM_WRITES=0, parameter PAYLOAD_RELAX=0)(
    input wire clk,reset,
    input wire req_valid, output wire req_ready, input wire [31:0] req_addr,req_wdata,
    input wire req_write, input wire [3:0] req_strobe,
    output wire rsp_valid, input wire rsp_ready, output wire [31:0] rsp_data, output wire rsp_error,
    output wire bus_valid, input wire bus_ready, output wire [31:0] bus_addr,bus_wdata,
    output wire bus_write, output wire [3:0] bus_strobe, output wire [2:0] bus_beats,
    input wire bus_rsp_valid, output wire bus_rsp_ready, input wire [31:0] bus_rsp_data,
    input wire bus_rsp_error,bus_rsp_last,
    output wire [31:0] hit_count,miss_count
);
    generate if(!ENABLE) begin:bypass
        assign hit_count=0;assign miss_count=0;
        assign req_ready=bus_ready;
        assign bus_valid=req_valid;
        assign bus_addr=req_addr; assign bus_wdata=req_wdata;
        assign bus_write=req_write; assign bus_strobe=req_strobe; assign bus_beats=1;
        assign rsp_valid=bus_rsp_valid; assign rsp_data=bus_rsp_data; assign rsp_error=bus_rsp_error;
        assign bus_rsp_ready=rsp_ready;
    end else begin:cached_impl
    localparam IDLE=0,LOOKUP=1,READ_REQ=2,READ_WAIT=3,WRITE_REQ=4,WRITE_WAIT=5,RESPONSE=6,HIT_WAIT=7;
    reg [2:0] state=IDLE;
    reg [31:0] address=0,wdata=0,rdata=0;
    reg writing=0,error=0,cached=0,victim=0,write_hit=0,write_way=0;
    reg posted_acked=0;
    // Optional SoC contract: ordinary on-chip RAM writes cannot return an
    // access fault. MMIO, ROM writes and all reads retain precise responses.
    wire posted_ram=POST_RAM_WRITES&&!READ_ONLY&&address[31:16]==16'h1000;
    wire post_response=state==WRITE_WAIT&&posted_ram&&!posted_acked;
    reg [3:0] strobe=0;
    reg [1:0] beat=0;
    reg valid0[0:63],valid1[0:63],lru[0:63];
    // Only 64KiB ROM and 64KiB RAM allocate. Their upper bits are fixed;
    // retain six in-region tag bits plus one ROM/RAM discriminator.
    localparam TAG_BITS=FAST_HIT?7:22;
    reg [TAG_BITS-1:0] tag0[0:63],tag1[0:63];
    wire [31:0] data0,data1;
    wire [31:0] lookup_address=FAST_HIT?req_addr:address;
    wire [5:0] lookup_set=lookup_address[9:4];
    wire [TAG_BITS-1:0] lookup_tag=FAST_HIT?{lookup_address[28],lookup_address[15:10]}:lookup_address[31:10];
    wire [TAG_BITS-1:0] saved_tag=FAST_HIT?{address[28],address[15:10]}:address[31:10];
    wire [5:0] set_index=address[9:4];
    wire [7:0] word_index=address[9:2];
    wire hit0=valid0[lookup_set]&&tag0[lookup_set]==lookup_tag;
    wire hit1=valid1[lookup_set]&&tag1[lookup_set]==lookup_tag;
    wire hit=hit0||hit1;
    reg lru_pending=0,lru_value=0;reg [5:0] lru_set=0;
    wire lookup_lru=LRU_PIPE&&lru_pending&&lru_set==lookup_set?lru_value:lru[lookup_set];
    wire saved_lru=LRU_PIPE&&lru_pending&&lru_set==set_index?lru_value:lru[set_index];
    wire incoming_cached=req_addr[31:16]==0||req_addr[31:16]==16'h1000;
    wire count_event=(FAST_HIT?(req_valid&&req_ready):state==LOOKUP);
    wire count_cached=FAST_HIT?incoming_cached:cached;
    wire count_read=FAST_HIT?!req_write:!writing;
    wire hit_event=count_event&&count_cached&&count_read&&hit;
    wire miss_event=count_event&&count_cached&&count_read&&!hit;
    reg [31:0] hit_total=0,miss_total=0;
    reg hit_pending=0,miss_pending=0;
    assign hit_count=hit_total+(COUNT_PIPE?hit_pending:1'b0);
    assign miss_count=miss_total+(COUNT_PIPE?miss_pending:1'b0);
    // Pending compensation exposes the original cycle-exact count, while
    // the request/tag logic only drives a one-bit event register, not 32 CEs.
    always @(posedge clk)begin
        if(reset)begin hit_total<=0;miss_total<=0;hit_pending<=0;miss_pending<=0;end
        else begin
            hit_pending<=hit_event;miss_pending<=miss_event;
            hit_total<=hit_total+(COUNT_PIPE?hit_pending:hit_event);
            miss_total<=miss_total+(COUNT_PIPE?miss_pending:miss_event);
        end
    end
    wire fill=state==READ_WAIT&&bus_rsp_valid&&cached;
    wire update=state==WRITE_WAIT&&bus_rsp_valid&&write_hit&&!bus_rsp_error;
    wire early_read=FAST_HIT&&req_ready&&req_valid&&!req_write&&incoming_cached;
    wire [7:0] bank_addr=fill?{set_index,beat}:early_read?req_addr[9:2]:word_index;
    wire [31:0] bank_wdata=fill?bus_rsp_data:wdata;
    wire [3:0] bank_strobe=fill?4'b1111:strobe;
    rv32_ram #(.ADDRESS_BITS(8)) bank0(clk,early_read||state==LOOKUP||(fill&&!victim)||(update&&!write_way),
        (fill&&!victim)||(update&&!write_way),bank_addr,bank_wdata,bank_strobe,data0);
    rv32_ram #(.ADDRESS_BITS(8)) bank1(clk,early_read||state==LOOKUP||(fill&&victim)||(update&&write_way),
        (fill&&victim)||(update&&write_way),bank_addr,bank_wdata,bank_strobe,data1);
    assign req_ready=!reset&&(state==IDLE||(FAST_HIT&&rsp_ready&&(state==HIT_WAIT||state==RESPONSE)));
    assign rsp_valid=state==RESPONSE||(FAST_HIT&&state==HIT_WAIT)||post_response;
    assign rsp_data=post_response?32'b0:FAST_HIT&&state==HIT_WAIT?(write_way?data1:data0):rdata; assign rsp_error=error;
    assign bus_valid=state==READ_REQ||state==WRITE_REQ;
    assign bus_addr=cached&&!writing?{address[31:4],4'b0}:address;
    assign bus_wdata=wdata; assign bus_write=writing; assign bus_strobe=strobe;
    assign bus_beats=cached&&!writing?4:1;
    assign bus_rsp_ready=state==READ_WAIT||state==WRITE_WAIT;
    wire lru_read=FAST_HIT?(req_valid&&req_ready&&!req_write&&incoming_cached&&hit):
        (state==LOOKUP&&!writing&&cached&&hit);
    wire lru_fill=state==READ_WAIT&&bus_rsp_valid&&bus_rsp_last&&cached&&!error&&!bus_rsp_error;
    wire lru_write=state==WRITE_WAIT&&bus_rsp_valid&&write_hit&&!bus_rsp_error;
    wire lru_event=lru_read||lru_fill||lru_write;
    wire [5:0] new_lru_set=(state==READ_WAIT||state==WRITE_WAIT)?set_index:lookup_set;
    wire new_lru_value=state==READ_WAIT?!victim:state==WRITE_WAIT?!write_way:!hit1;
    integer li;
    always @(posedge clk)begin
        if(reset)begin
            lru_pending<=0;
            for(li=0;li<64;li=li+1)lru[li]<=0;
        end else begin
            lru_pending<=lru_event;lru_set<=new_lru_set;lru_value<=new_lru_value;
            // The pending update forwards into victim selection, preserving
            // exact replacement decisions on back-to-back same-set traffic.
            if(LRU_PIPE)begin if(lru_pending)lru[lru_set]<=lru_value;end
            else if(lru_event)lru[new_lru_set]<=new_lru_value;
        end
    end
    integer j,k;
    initial for(j=0;j<64;j=j+1) begin valid0[j]=0; valid1[j]=0; lru[j]=0; tag0[j]=0; tag1[j]=0; end
    always @(posedge clk) begin
        if(reset) begin
            state<=IDLE;posted_acked<=0;
            for(j=0;j<64;j=j+1) begin valid0[j]<=0; valid1[j]<=0; end
        end else begin
        if(post_response&&rsp_ready)posted_acked<=1;
        // req_ready guarantees a vacant/departing transaction. Dead payload
        // may sample freely; only the accepted-request FSM owns its validity.
        // In particular, victim selection does not need the hit/miss result.
        if(FAST_HIT&&PAYLOAD_RELAX&&req_ready)begin
            address<=req_addr;wdata<=req_wdata;writing<=req_write;strobe<=req_strobe;
            cached<=incoming_cached;error<=0;beat<=0;
            write_hit<=incoming_cached&&hit;write_way<=hit1;
            victim<=!valid0[lookup_set]?0:!valid1[lookup_set]?1:lookup_lru;
        end
        case(state)
            IDLE: if(!FAST_HIT&&req_valid) begin
                posted_acked<=0;
                address<=req_addr; wdata<=req_wdata; writing<=req_write; strobe<=req_strobe;
                cached<=ENABLE&&(req_addr[31:16]==0||req_addr[31:16]==16'h1000);
                error<=0; beat<=0; state<=LOOKUP;

            end
            LOOKUP: begin
                if(writing) begin
                    write_hit<=cached&&hit; write_way<=hit1;
                    if(READ_ONLY) begin error<=1; state<=RESPONSE; end else state<=WRITE_REQ;
                end else if(cached&&hit) begin
                    write_way<=hit1;
                    state<=HIT_WAIT;
                end else begin
                    victim<=!valid0[set_index]?0:!valid1[set_index]?1:saved_lru;
                    state<=READ_REQ;
                end
            end
            READ_REQ: if(bus_ready) begin
                state<=READ_WAIT;
                if(cached) begin
                    if(victim) valid1[set_index]<=0; else valid0[set_index]<=0;
                end
            end
            READ_WAIT: if(bus_rsp_valid) begin
                error<=error||bus_rsp_error;
                if(!cached||beat==address[3:2]) rdata<=bus_rsp_data;
                beat<=beat+1'b1;
                if(bus_rsp_last) begin
                    if(cached&&!error&&!bus_rsp_error) begin
                        if(victim) begin valid1[set_index]<=1; tag1[set_index]<=saved_tag; end
                        else begin valid0[set_index]<=1; tag0[set_index]<=saved_tag; end

                    end
                    state<=RESPONSE;
                end
            end
            WRITE_REQ: if(bus_ready) state<=WRITE_WAIT;
            WRITE_WAIT: if(bus_rsp_valid) begin
                error<=bus_rsp_error; rdata<=0;
                // Already acknowledged stores continue draining through the
                // cache across CPU redirects. New memory traffic stays blocked
                // until the backing write and hit-line update have completed.
                state<=posted_ram&&(posted_acked||rsp_ready)?IDLE:RESPONSE;
            end
            RESPONSE: if(rsp_ready) state<=IDLE;
            HIT_WAIT: if(FAST_HIT) begin if(rsp_ready) state<=IDLE; end
                else begin rdata<=write_way?data1:data0; state<=RESPONSE; end
            default: state<=IDLE;
        endcase
                if(FAST_HIT&&req_valid&&req_ready) begin
                    posted_acked<=0;
                    if(!PAYLOAD_RELAX)begin
                    address<=req_addr; wdata<=req_wdata; writing<=req_write; strobe<=req_strobe;
                    cached<=incoming_cached; error<=0; beat<=0;
                    end
                    if(req_write) begin
                        if(!PAYLOAD_RELAX)begin write_hit<=incoming_cached&&hit; write_way<=hit1;end
                        if(READ_ONLY) begin error<=1; state<=RESPONSE; end else state<=WRITE_REQ;
                    end else if(incoming_cached&&hit) begin
                        if(!PAYLOAD_RELAX)write_way<=hit1;
                        state<=HIT_WAIT;
                    end else begin
                        if(!PAYLOAD_RELAX)victim<=!valid0[lookup_set]?0:!valid1[lookup_set]?1:lookup_lru;
                        state<=READ_REQ;
                    end
                end
        end
    end
    end endgenerate
endmodule
