// Five-stage, in-order, single-issue CPU. Three elastic IF entries reserve room
// for the single outstanding request; redirects discard all younger entries.
// EX forwards MEM/WB; a pending load holds dependent EX instructions. CSR and
// FENCE instructions serialize the pipe. Stores/MMIO issue only behind safe WB.
module rv32_pipeline #(parameter CSR_ENABLE=1, parameter PREDICT=0, parameter STREAM_FETCH=1, parameter ZMMUL=1,
    parameter FAST_LOAD=1, parameter MUL_EARLY=1, parameter LOAD_BYPASS=2,
    parameter BTB_BITS=6, parameter BTB_COMPACT=1, parameter INDIRECT=1, parameter PREDICT_LATE=1, parameter PARALLEL_BRANCH=1,
    parameter OPERAND_HOLD=1, parameter DSP_STREAM=1, parameter QUEUE_DATA=1, parameter SPLIT_TARGET=1, parameter TRAIN_DATA=1,
    parameter PC_ANCHOR=0, parameter RF_RAM=0, parameter RELAX_FORWARD=0, parameter BHT_BITS=0, parameter GSHARE=0, parameter RAS_BITS=0,
    parameter SERIAL_FLAGS=1, parameter EARLY_MEMORY=0, parameter FWD_SELECT=0, parameter DELAY_BRANCH=0)(
    input wire clk, reset,
    output wire i_valid, input wire i_ready, output wire [31:0] i_addr,
    input wire i_rsp_valid, output wire i_rsp_ready, input wire [31:0] i_rsp_data, input wire i_rsp_error,
    output wire d_valid, input wire d_ready, output wire [31:0] d_addr, d_wdata,
    output wire d_write, output wire [3:0] d_strobe,
    input wire d_rsp_valid, output wire d_rsp_ready, input wire [31:0] d_rsp_data, input wire d_rsp_error,
    input wire timer_irq, software_irq, external_irq,
    output reg halted=0, output reg trace_valid=0,
    output reg [31:0] trace_pc=0, trace_insn=0, trace_data=0, trace_cause=0,
    output reg [4:0] trace_rd=0, output reg trace_trap=0,
    output wire [63:0] cycles, retired,
    output wire [31:0] debug_if_pc, debug_id_pc, debug_ex_pc, debug_mem_pc, debug_wb_pc,
    output wire [4:0] debug_valid, output wire debug_stall, debug_flush,
    output wire [31:0] branch_count, mispredict_count, stall_count
);
    wire [31:0] register_a,register_b;
    reg [31:0] branch_total=0,miss_total=0,stall_total=0;
    reg branch_pending=0,miss_pending=0,stall_pending=0;
    wire branch_event,miss_event,stall_event;
    // Pipeline the event-to-counter enable path, while exposing pending
    // events in the same atomic epoch as the original EX-stage counters.
    assign branch_count=branch_total+branch_pending;
    assign mispredict_count=miss_total+miss_pending;
    assign stall_count=stall_total+stall_pending;
    always @(posedge clk)begin
        if(reset)begin branch_total<=0;miss_total<=0;stall_total<=0;branch_pending<=0;miss_pending<=0;stall_pending<=0;end
        else begin
            branch_total<=branch_total+branch_pending;miss_total<=miss_total+miss_pending;stall_total<=stall_total+stall_pending;
            branch_pending<=branch_event;miss_pending<=miss_event;stall_pending<=stall_event;
        end
    end
    reg [31:0] fetch_pc=0, pending_pc=0, pending_pred=0;
    reg pending=0, stale=0;
    reg fv=0,iv=0,xv=0,mv=0,wv=0;
    reg qv=0;
    reg tv=0;
    reg [31:0] ti=0,tp=0,tn=0;
    reg tfault=0;
    reg [31:0] qi=0,qp=0,qn=0;
    reg qfault=0;
    reg [31:0] fi=0,fp=0,fn=0,ii=0,ip=0,inext=0,xi=0,xp=0,xpred=0;
    reg ffault=0,ifault=0,xfault=0;
    reg [31:0] xa=0,xb=0;
    reg [31:0] mi=0,mp=0,mnext=0,mresult=0,maddr=0,mwd=0,mcause=0,mtval=0,ma=0;
    reg [4:0] mrd=0;
    reg [3:0] mbe=0;
    reg mwr=0,mload=0,mstore=0,msys=0,mfault=0,msent=0,mdone=0;
    reg [31:0] wi=0,wp=0,wnext=0,wresult=0,wcause=0,wtval=0,wa=0;
    reg [4:0] wrd=0;
    reg wwr=0,wsys=0,wfault=0,wmret=0;
    wire system_fault,system_mret;
    wire [31:0] system_cause,system_tval;
    rv32_system_decode #(.ENABLE(CSR_ENABLE)) system_decode(
        msys,mi,mp,system_fault,system_cause,system_tval,system_mret);
    wire [31:0] csr_read,csr_cause,raw_csr_target,csr_target,sequential_pc;
    // Preserve arithmetic boundaries: conditional resource sharing must not
    // move the CSR vector/PC increment carry chain behind BTB selection.
    generate if(PC_ANCHOR)begin: pc_arithmetic
        wire [31:0] csr_path /* synthesis syn_keep=1 */;
        wire [31:0] step_path /* synthesis syn_keep=1 */;
        assign csr_path=raw_csr_target;assign step_path=fetch_pc+4;
        assign csr_target=csr_path;assign sequential_pc=step_path;
    end else begin: pc_original
        assign csr_target=raw_csr_target;assign sequential_pc=fetch_pc+4;
    end endgenerate
    wire csr_redirect,csr_exception,csr_halt;
    // An accepted younger MMIO/store must retire before an asynchronous interrupt.
    // Otherwise flushing MEM could discard a response after an irreversible side effect.
    wire irq_boundary_safe=!(mv&&(mload||mstore)&&msent);
    rv32_csr #(.ENABLE(CSR_ENABLE),.PREDECODE(1)) csr(clk,reset,wv,wsys,wfault,wi,wp,wnext,wa,wcause,wtval,
        timer_irq&&irq_boundary_safe,software_irq&&irq_boundary_safe,external_irq&&irq_boundary_safe,
        csr_read,csr_redirect,csr_exception,csr_halt,raw_csr_target,csr_cause,cycles,retired,wmret);
    wire [31:0] wb_data=wsys&&wi[14:12]!=0?csr_read:wresult;
    wire wb_write=wv&&wwr&&wrd!=0&&!csr_exception;
    // System instructions drain/serialize the pipeline. Their architectural
    // register write remains qualified by CSR exception, but no younger EX/ID
    // instruction needs their WB forwarding. Keep CSR read/legality off bypass.
    // Faulting older instructions kill every younger result before commit.
    // Their data may therefore forward into dead EX/ID payload; request and
    // retirement qualification still retain the precise-fault/CSR guards.
    wire wb_forward=wv&&wwr&&!wsys&&(RELAX_FORWARD||(!wfault&&wrd!=0));
    rv32_register_file #(.DISTRIBUTED(RF_RAM)) register_file(clk,reset,!halted&&wb_write,
        wrd,wb_data,ii[19:15],ii[24:20],register_a,register_b);
    wire [4:0] rs1,rs2,rd;
    wire use1,use2,xwr,xld,xst,xsys,xtrap;
    wire [31:0] result,npc,addr,wd,ec,et;
    wire [3:0] be;
    wire is_multiply=ZMMUL&&xi[6:0]==7'h33&&xi[31:25]==1&&!xi[14];
    wire is_control=xi[6:0]==7'h63||xi[6:0]==7'h6f||xi[6:0]==7'h67;
    wire forward_eligible=LOAD_BYPASS==1||(LOAD_BYPASS==2&&!is_control&&!is_multiply);
    wire forward_a=forward_eligible||((LOAD_BYPASS==3||LOAD_BYPASS==4)&&!xld&&!xst&&!is_multiply&&(LOAD_BYPASS==3||!is_control));
    wire forward_b=forward_eligible||((LOAD_BYPASS==3||LOAD_BYPASS==4)&&!is_multiply&&(LOAD_BYPASS==3||!is_control));
    reg sm1=0,sm2=0,sw1=0,sw2=0;
    reg zero1=1,zero2=1;
    wire match_m1=FWD_SELECT?sm1:(mrd!=0&&mrd==rs1),match_m2=FWD_SELECT?sm2:(mrd!=0&&mrd==rs2);
    wire match_w1=FWD_SELECT?sw1:(wrd==rs1),match_w2=FWD_SELECT?sw2:(wrd==rs2);
    reg redirect_pending=0;reg [31:0] redirect_target=0;
    reg [31:0] loaded;
    wire data_complete=d_rsp_valid&&d_rsp_ready;
    wire return_now=FAST_LOAD&&data_complete;
    wire load_available_a=mdone||(return_now&&(forward_a||!mload));
    wire load_available_b=mdone||(return_now&&(forward_b||!mload));
    wire response_fault=return_now&&d_rsp_error;
    wire mem_fault=mfault||response_fault;
    wire [31:0] mem_result=mload&&!mdone&&return_now?loaded:mresult;
    reg [31:0] a,b,base_a,base_b;
    always @* begin
        base_a=xa;base_b=xb;
        if(((FWD_SELECT&&RELAX_FORWARD)||wb_forward) && match_w1) base_a=wresult;
        if(((FWD_SELECT&&RELAX_FORWARD)||wb_forward) && match_w2) base_b=wresult;
        if(((FWD_SELECT&&RELAX_FORWARD)||(mv&&mwr&&(RELAX_FORWARD||(mrd!=0&&!mfault))))&&(!mload||mdone)) begin
            if(match_m1) base_a=mresult;
            if(match_m2) base_b=mresult;
        end
        if((FWD_SELECT&&RELAX_FORWARD)?zero1:(rs1==0))base_a=0;
        if((FWD_SELECT&&RELAX_FORWARD)?zero2:(rs2==0))base_b=0;
        a=base_a;b=base_b;
        if(mv&&mwr&&mrd!=0&&!mem_fault&&mload&&return_now)begin
            if(match_m1&&forward_a)a=loaded;if(match_m2&&forward_b)b=loaded;
        end
    end
    rv32_execute #(.ZMMUL(ZMMUL)) execute(xi,xp,a,b,rs1,rs2,rd,use1,use2,xwr,xld,xst,xsys,result,npc,addr,wd,be,xtrap,ec,et);
    wire load_hazard=xv&&mv&&mload&&((use1&&match_m1&&!load_available_a)||(use2&&match_m2&&!load_available_b));
    wire mem_leave=mv&&(!(mload||mstore)||mdone||return_now);
    wire mem_space=!mv||mem_leave;
    wire multiply_deferred=return_now&&mload&&!mdone&&((use1&&match_m1)||(use2&&match_m2));
    wire multiply_busy,multiply_ready;
    wire [31:0] multiply_result;
    wire ex_fire=xv&&mem_space&&!load_hazard&&!response_fault&&!csr_redirect&&!(DELAY_BRANCH&&redirect_pending)&&(!is_multiply||xfault||multiply_ready);
    wire ex_space=!xv||ex_fire;
    wire id_serial=(ii[6:0]==7'h73)||(ii[6:0]==7'h0f);
    reg xs=0,ms=0,ws=0;
    wire x_serial=xv&&(SERIAL_FLAGS?xs:((xi[6:0]==7'h73)||(xi[6:0]==7'h0f)));
    wire m_serial=mv&&(SERIAL_FLAGS?ms:((mi[6:0]==7'h73)||(mi[6:0]==7'h0f)));
    wire w_serial=wv&&(SERIAL_FLAGS?ws:((wi[6:0]==7'h73)||(wi[6:0]==7'h0f)));
    wire serial_busy=(iv&&id_serial)||x_serial||m_serial||w_serial;
    wire id_fire=iv&&ex_space&&!csr_redirect&&!(DELAY_BRANCH&&redirect_pending)&&!x_serial&&!m_serial&&!w_serial&&(!id_serial||(!xv&&!mv&&!wv));
    wire id_space=!iv||id_fire;
    // Destination comparisons are prepared for the next EX slot. While EX
    // is held, MEM-to-WB transfer migrates the selector and held operands
    // retain their forwarded value. No response data enters these controls.
    wire next_m_valid=ex_fire?(xwr&&(RELAX_FORWARD||(!xfault&&!xtrap))):(mv&&!mem_leave&&mwr&&(RELAX_FORWARD||!mfault));
    wire [4:0] next_m_rd=ex_fire?rd:mrd;
    wire next_w_valid=mem_leave&&mwr&&(RELAX_FORWARD||!mem_fault)&&!msys;
    always @(posedge clk)begin
        if(reset)begin sm1<=0;sm2<=0;sw1<=0;sw2<=0;zero1<=1;zero2<=1;end
        else if(!halted)begin
            if(id_fire)begin
                zero1<=ii[19:15]==0;zero2<=ii[24:20]==0;
                sm1<=next_m_valid&&next_m_rd!=0&&next_m_rd==ii[19:15];
                sm2<=next_m_valid&&next_m_rd!=0&&next_m_rd==ii[24:20];
                sw1<=next_w_valid&&mrd!=0&&mrd==ii[19:15];
                sw2<=next_w_valid&&mrd!=0&&mrd==ii[24:20];
            end else begin
                sm1<=sm1&&!mem_leave;sm2<=sm2&&!mem_leave;
                sw1<=next_w_valid&&sm1;sw2<=next_w_valid&&sm2;
            end
        end
    end
    always @(posedge clk)if(!reset&&!halted)begin
        if(id_fire)xs<=id_serial;
        if(ex_fire)ms<=xs;
        if(mem_leave)ws<=ms;
    end
    // Compare both possible PCs before the operand-dependent branch decision.
    // This avoids serialising the compare behind the wide next-PC mux.
    wire [31:0] branch_pc=xp+{{19{xi[31]}},xi[31],xi[7],xi[30:25],xi[11:8],1'b0};
    wire fallthrough_miss=xp+4!=xpred;
    reg branch_taken;
    always @* case(xi[14:12])
        0:branch_taken=a==b;1:branch_taken=a!=b;
        4:branch_taken=$signed(a)<$signed(b);5:branch_taken=$signed(a)>=$signed(b);
        6:branch_taken=a<b;7:branch_taken=a>=b;default:branch_taken=0;
    endcase
    wire conditional_branch=xi[6:0]==7'h63;
    wire branch_legal=xi[14:12]!=2&&xi[14:12]!=3&&(!branch_taken||branch_pc[1:0]==0);
    wire [31:0] jal_pc=xp+{{11{xi[31]}},xi[31],xi[19:12],xi[20],xi[30:21],1'b0};
    wire [31:0] jalr_sum=a+{{20{xi[31]}},xi[31:20]};
    wire [31:0] jalr_pc={jalr_sum[31:1],1'b0};
    // Keep operand-dependent branch selection out of the JAL/JALR target
    // comparisons. Their opcode-qualified paths are independent of BEQ/BLT.
    wire split_miss=(conditional_branch&&branch_legal&&(branch_taken?(branch_pc!=xpred):fallthrough_miss))||
        (xi[6:0]==7'h6f&&jal_pc[1:0]==0&&jal_pc!=xpred)||
        (xi[6:0]==7'h67&&xi[14:12]==0&&!jalr_pc[1]&&jalr_pc!=xpred)||
        (!is_control&&fallthrough_miss);
    wire parallel_miss=SPLIT_TARGET?split_miss:conditional_branch?(branch_legal&&(branch_taken?(branch_pc!=xpred):fallthrough_miss)):
        (is_control?(!xtrap&&npc!=xpred):fallthrough_miss);
    wire branch_resolve=ex_fire&&!xfault&&(PARALLEL_BRANCH?parallel_miss:(is_control?(!xtrap&&npc!=xpred):fallthrough_miss));
    wire branch_flush=DELAY_BRANCH?redirect_pending:branch_resolve;
    always @(posedge clk)begin
        if(reset)redirect_pending<=0;
        else begin
            redirect_pending<=!halted&&branch_resolve;
            // redirect_pending owns validity. Do not put target comparison
            // on the clock enable of the 32-bit target payload.
            redirect_target<=npc;
        end
    end
    wire flush=csr_redirect||branch_flush;
    assign branch_event=!halted&&ex_fire&&is_control;
    assign miss_event=branch_event&&branch_resolve;
    assign stall_event=!halted&&xv&&!ex_fire;
    reg multiply_cancel=0;
    // CSR redirection empties EX; cancellation can safely arrive one cycle
    // later, before a new instruction reaches EX. A branch redirect consumes
    // its own EX operation, so it cannot cancel a different active multiply.
    always @(posedge clk)if(reset)multiply_cancel<=0;else multiply_cancel<=csr_redirect;
    generate if(ZMMUL) begin: multiplier
        rv32_multiply #(.EARLY_LOW(MUL_EARLY),.STREAM_PRODUCTS(DSP_STREAM)) unit(clk,reset||multiply_cancel,
            xv&&is_multiply&&!xfault&&!load_hazard&&!multiply_deferred&&!response_fault&&!multiply_busy&&!csr_redirect&&!(DELAY_BRANCH&&redirect_pending),
            ex_fire&&is_multiply,base_a,base_b,xi[13:12],multiply_busy,multiply_ready,multiply_result);
    end else begin: no_multiplier
        assign multiply_busy=0;assign multiply_ready=0;assign multiply_result=0;
    end endgenerate
    wire [31:0] target=csr_redirect?csr_target:(DELAY_BRANCH?redirect_target:npc);
    // The executable ROM occupies 64KiB. Compact entries only predict within
    // that region; arbitrary/out-of-ROM architectural targets still resolve
    // normally in EX. This permits a larger table without full 32-bit tags.
    localparam BTB_ENTRIES=1<<BTB_BITS;
    localparam BTB_TAG_BITS=BTB_COMPACT?14-BTB_BITS:30-BTB_BITS;
    localparam BTB_TARGET_BITS=BTB_COMPACT?14:32;
    reg bv[0:BTB_ENTRIES-1]; reg [BTB_TAG_BITS-1:0] btag[0:BTB_ENTRIES-1];
    reg [BTB_TARGET_BITS-1:0] btarget[0:BTB_ENTRIES-1]; reg [1:0] bcounter[0:BTB_ENTRIES-1];
    wire [BTB_BITS-1:0] findex=fetch_pc[BTB_BITS+1:2], xindex=xp[BTB_BITS+1:2];
    wire [BTB_TAG_BITS-1:0] ftag=BTB_COMPACT?fetch_pc[15:BTB_BITS+2]:fetch_pc[31:BTB_BITS+2];
    wire [BTB_TAG_BITS-1:0] xtag=BTB_COMPACT?xp[15:BTB_BITS+2]:xp[31:BTB_BITS+2];
    // Separate direction state prevents BTB target conflicts from erasing
    // branch bias. GShare carries the prediction-time index through IF/ID/EX.
    localparam HB=BHT_BITS>0?BHT_BITS:1;
    localparam RB=RAS_BITS>0?RAS_BITS:1;
    reg [1:0] direction[0:(1<<HB)-1];
    reg [HB-1:0] history=0;
    wire [HB-1:0] prediction_index=fetch_pc[HB+1:2]^(GSHARE?history:{HB{1'b0}});
    reg [HB-1:0] pending_history=0,fh=0,qh=0,th=0,ih=0,xh=0,train_history=0;
    reg bconditional[0:BTB_ENTRIES-1],breturn[0:BTB_ENTRIES-1];
    reg train_conditional=0,train_return=0;
    wire train_event,payload_push,payload_pop;
    reg [31:0] ras[0:(1<<RB)-1];
    reg [RB-1:0] ras_pointer=0;
    reg [RB:0] ras_count=0;
    wire call_rd=xi[11:7]==1||xi[11:7]==5;
    wire return_rs=xi[19:15]==1||xi[19:15]==5;
    wire call_event=train_event&&(xi[6:0]==7'h6f||xi[6:0]==7'h67)&&call_rd;
    wire return_event=train_event&&xi[6:0]==7'h67&&return_rs&&xi[11:7]!=xi[19:15];
    wire predicted=PREDICT&&(!BTB_COMPACT||fetch_pc[31:16]==0)&&bv[findex]&&btag[findex]==ftag&&(BHT_BITS?(!bconditional[findex]||direction[prediction_index][1]):bcounter[findex][1]);
    wire [31:0] predicted_target=BTB_COMPACT?{16'b0,btarget[findex],2'b0}:btarget[findex];
    wire [31:0] ras_target=ras[ras_pointer-1'b1];
    wire [31:0] prediction=predicted?((RAS_BITS&&breturn[findex]&&ras_count!=0)?ras_target:predicted_target):sequential_pc;
    assign train_event=!halted&&PREDICT&&ex_fire&&is_control&&!xfault&&!xtrap&&(INDIRECT||xi[6:0]!=7'h67)&&
        (!BTB_COMPACT||(xp[31:16]==0&&npc[31:16]==0));
    reg train_pending=0,train_taken=0;
    reg [BTB_BITS-1:0] train_index=0;
    reg [BTB_TAG_BITS-1:0] train_tag=0;
    reg [BTB_TARGET_BITS-1:0] train_target=0;
    always @(posedge clk)begin
        if(reset)train_pending<=0;
        else begin
            train_pending<=train_event;
            // train_pending owns validity; dead payload need not hold.
            if(TRAIN_DATA||train_event)begin
                train_index<=xindex;train_tag<=xtag;train_target<=BTB_COMPACT?npc[15:2]:npc;train_taken<=npc!=xp+4;
            end
        end
    end
    wire update_event=PREDICT_LATE?train_pending:train_event;
    wire [BTB_BITS-1:0] update_index=PREDICT_LATE?train_index:xindex;
    wire [BTB_TAG_BITS-1:0] update_tag=PREDICT_LATE?train_tag:xtag;
    wire [BTB_TARGET_BITS-1:0] update_target=PREDICT_LATE?train_target:(BTB_COMPACT?npc[15:2]:npc);
    wire update_taken=PREDICT_LATE?train_taken:npc!=xp+4;
    wire update_conditional=PREDICT_LATE?train_conditional:conditional_branch;
    wire update_return=PREDICT_LATE?train_return:(xi[6:0]==7'h67&&return_rs&&xi[11:7]!=xi[19:15]);
    wire [HB-1:0] update_history=PREDICT_LATE?train_history:xh;
    integer pi;
    initial begin
        for(pi=0;pi<(1<<HB);pi=pi+1)direction[pi]=1;
        for(pi=0;pi<BTB_ENTRIES;pi=pi+1)begin bconditional[pi]=0;breturn[pi]=0;end
    end
    always @(posedge clk)begin
        if(reset)begin
            history<=0;ras_count<=0;ras_pointer<=0;
            for(pi=0;pi<(1<<HB);pi=pi+1)direction[pi]<=1;
        end else if(!halted)begin
            if(i_valid&&i_ready)pending_history<=prediction_index;
            if(payload_pop)begin
                if(qv)fh<=qh;else if(payload_push)fh<=pending_history;
                if(tv)qh<=th;else if(qv&&payload_push)qh<=pending_history;
                if(tv&&payload_push)th<=pending_history;
            end else if(payload_push)begin
                if(!fv)fh<=pending_history;else if(!qv)qh<=pending_history;else th<=pending_history;
            end
            if(payload_pop)ih<=fh;
            if(id_fire)xh<=ih;
            if(TRAIN_DATA||train_event)begin
                train_history<=xh;train_conditional<=conditional_branch;
                train_return<=xi[6:0]==7'h67&&return_rs&&xi[11:7]!=xi[19:15];
            end
            if(update_event)begin
                bconditional[update_index]<=update_conditional;breturn[update_index]<=update_return;
                if(BHT_BITS&&update_conditional)begin
                    if(update_taken&&direction[update_history]!=3)direction[update_history]<=direction[update_history]+1'b1;
                    else if(!update_taken&&direction[update_history]!=0)direction[update_history]<=direction[update_history]-1'b1;
                end
            end
            if(BHT_BITS&&GSHARE&&train_event&&conditional_branch)history<=(history<<1)|(npc!=xp+4);
            if(RAS_BITS)begin
                if(call_event&&return_event&&ras_count!=0)ras[ras_pointer-1'b1]<=xp+4;
                else if(call_event)begin
                    ras[ras_pointer]<=xp+4;ras_pointer<=ras_pointer+1'b1;
                    if(ras_count<(1<<RB))ras_count<=ras_count+1'b1;
                end else if(return_event&&ras_count!=0)begin ras_pointer<=ras_pointer-1'b1;ras_count<=ras_count-1'b1;end
            end
        end
    end
    // The extra slot permits a new request while the preceding response
    // arrives. Reserve worst-case space without a combinational ID/EX-ready
    // path into ROM enable. STREAM_FETCH=0 reproduces the two-entry parent.
    assign i_valid=!reset&&!halted&&!serial_busy&&
        (STREAM_FETCH?(!tv&&(!pending||(i_rsp_valid&&!qv))):(!pending&&!qv));
    assign i_addr=fetch_pc; assign i_rsp_ready=pending;
    wire fetch_push=i_rsp_valid&&i_rsp_ready&&!stale&&!flush;
    wire fetch_pop=fv&&id_space&&!flush;
    assign payload_push=i_rsp_valid&&i_rsp_ready&&!stale;
    assign payload_pop=fv&&id_space;
    wire mem_request=mv&&(mload||mstore)&&!mfault&&!msent&&!csr_redirect;
    // Only ordinary on-chip accesses may fork at EX. The older MEM slot
    // must be fault-free before a younger access can become irreversible;
    // MMIO and ROM writes retain their original committed MEM request path.
    wire [31:0] mem_immediate=xld?{{20{xi[31]}},xi[31:20]}:{{20{xi[31]}},xi[31:25],xi[11:7]};
    wire [31:0] early_address=(LOAD_BYPASS==3||LOAD_BYPASS==4)?base_a+mem_immediate:addr;
    wire early_region=early_address[31:16]==16'h1000||(xld&&early_address[31:16]==0);
    wire legal_memory=(xi[14:12]==0)||(xi[14:12]==1&&!early_address[0])||
        (xi[14:12]==2&&early_address[1:0]==0)||(xld&&xi[14:12]==4)||(xld&&xi[14:12]==5&&!early_address[0]);
    wire [31:0] early_store_data=(LOAD_BYPASS==3||LOAD_BYPASS==4)?b<<(early_address[1:0]*8):wd;
    wire [3:0] early_strobe=(LOAD_BYPASS==3||LOAD_BYPASS==4)?
        (xi[14:12]==0?4'b1<<early_address[1:0]:xi[14:12]==1?4'b11<<early_address[1:0]:xi[14:12]==2?4'b1111:4'b0):be;
    wire early_request=EARLY_MEMORY&&ex_fire&&(xld||xst)&&!xfault&&legal_memory&&early_region&&
        (!mv||(!mem_fault&&!system_fault&&!msys))&&!mem_request;
    assign d_valid=!reset&&(mem_request||early_request);
    // Payload selection need not wait for legality, IRQ or ex_fire. When
    // neither request is valid these pins are don't-care; the registered
    // MEM ownership bits alone choose the payload of an accepted request.
    wire select_early=EARLY_MEMORY&&!(mv&&(mload||mstore)&&!mfault&&!msent);
    assign d_addr=select_early?early_address:maddr;assign d_wdata=select_early?early_store_data:mwd;
    assign d_write=select_early?xst:mstore;assign d_strobe=select_early?early_strobe:mbe;
    assign d_rsp_ready=mv&&msent&&!mdone;
    assign debug_if_pc=fetch_pc; assign debug_id_pc=ip; assign debug_ex_pc=xp;
    assign debug_mem_pc=mp; assign debug_wb_pc=wp;
    assign debug_valid={wv,mv,xv,iv,fv}; assign debug_stall=xv&&!ex_fire; assign debug_flush=flush;
    wire [31:0] shifted=d_rsp_data>>(maddr[1:0]*8);
    always @* case(mi[14:12])
        0: loaded={{24{shifted[7]}},shifted[7:0]};
        1: loaded={{16{shifted[15]}},shifted[15:0]};
        2: loaded=shifted; 4: loaded={24'b0,shifted[7:0]};
        5: loaded={16'b0,shifted[15:0]}; default: loaded=0;
    endcase
    integer j;
    initial begin

        for(j=0;j<BTB_ENTRIES;j=j+1) begin bv[j]=0; btag[j]=0; btarget[j]=0; bcounter[j]=1; end
    end
    // Valid bits discard killed entries. Their payload may still shift on a
    // redirect edge: it is dead, and the next valid push overwrites it. This
    // removes branch resolution from hundreds of payload clock enables.
    always @(posedge clk)if(QUEUE_DATA&&!reset&&!halted)begin
        if(payload_pop)begin
            if(qv)begin fi<=qi;fp<=qp;fn<=qn;ffault<=qfault;end
            else if(payload_push)begin fi<=i_rsp_data;fp<=pending_pc;fn<=pending_pred;ffault<=i_rsp_error;end
            if(tv)begin qi<=ti;qp<=tp;qn<=tn;qfault<=tfault;end
            else if(qv&&payload_push)begin qi<=i_rsp_data;qp<=pending_pc;qn<=pending_pred;qfault<=i_rsp_error;end
            if(tv&&payload_push)begin ti<=i_rsp_data;tp<=pending_pc;tn<=pending_pred;tfault<=i_rsp_error;end
        end else if(payload_push)begin
            if(!fv)begin fi<=i_rsp_data;fp<=pending_pc;fn<=pending_pred;ffault<=i_rsp_error;end
            else if(!qv)begin qi<=i_rsp_data;qp<=pending_pc;qn<=pending_pred;qfault<=i_rsp_error;end
            else begin ti<=i_rsp_data;tp<=pending_pc;tn<=pending_pred;tfault<=i_rsp_error;end
        end
        if(payload_pop)begin ii<=fi;ip<=fp;inext<=fn;ifault<=ffault;end
        if(id_fire)begin xi<=ii;xp<=ip;xpred<=inext;xfault<=ifault;end
    end
    always @(posedge clk) begin
        trace_valid<=0; wv<=0;
        if(reset) begin
            fetch_pc<=0; pending<=0; stale<=0; fv<=0; qv<=0; tv<=0; iv<=0; xv<=0; mv<=0; wv<=0; halted<=0;

            for(j=0;j<BTB_ENTRIES;j=j+1) begin bv[j]<=0; bcounter[j]<=1; end
        end else if(!halted) begin
            if(update_event)begin
                bv[update_index]<=1;btag[update_index]<=update_tag;
                if(update_taken)btarget[update_index]<=update_target;
                if(!bv[update_index]||btag[update_index]!=update_tag)bcounter[update_index]<=update_taken?2:1;
                else if(update_taken&&bcounter[update_index]!=3)bcounter[update_index]<=bcounter[update_index]+1'b1;
                else if(!update_taken&&bcounter[update_index]!=0)bcounter[update_index]<=bcounter[update_index]-1'b1;
            end
            if(wv) begin
                trace_valid<=1; trace_pc<=wp; trace_insn<=wi; trace_data<=wb_data;
                trace_rd<=wwr&&!csr_exception?wrd:0; trace_trap<=csr_exception; trace_cause<=csr_cause;

                if(csr_halt) halted<=1;
            end
            if(i_rsp_valid&&i_rsp_ready) begin
                pending<=0;
            end
            // New metadata wins when an old response and new request overlap.
            // The queue below still samples the preceding pending metadata.
            if(i_valid&&i_ready) begin
                pending<=1; pending_pc<=fetch_pc; pending_pred<=prediction; stale<=0; fetch_pc<=prediction;
            end
            // Simultaneous pop/push replaces the head without losing either
            // instruction. Tail metadata travels with its instruction/error.
            if(fetch_pop) begin
                fv<=qv||fetch_push;
                qv<=tv||(qv&&fetch_push);
                tv<=tv&&fetch_push;
                if(!QUEUE_DATA)begin
                if(qv) begin fi<=qi; fp<=qp; fn<=qn; ffault<=qfault; end
                else if(fetch_push) begin
                    fi<=i_rsp_data; fp<=pending_pc; fn<=pending_pred; ffault<=i_rsp_error;
                end
                if(tv) begin qi<=ti; qp<=tp; qn<=tn; qfault<=tfault; end
                else if(qv&&fetch_push) begin
                    qi<=i_rsp_data; qp<=pending_pc; qn<=pending_pred; qfault<=i_rsp_error;
                end
                if(tv&&fetch_push) begin
                    ti<=i_rsp_data; tp<=pending_pc; tn<=pending_pred; tfault<=i_rsp_error;
                end
                end
            end else if(fetch_push) begin
                if(!fv) begin
                    fv<=1;if(!QUEUE_DATA)begin fi<=i_rsp_data; fp<=pending_pc; fn<=pending_pred; ffault<=i_rsp_error;end
                end else if(!qv) begin
                    qv<=1;if(!QUEUE_DATA)begin qi<=i_rsp_data; qp<=pending_pc; qn<=pending_pred; qfault<=i_rsp_error;end
                end else begin
                    tv<=1;if(!QUEUE_DATA)begin ti<=i_rsp_data; tp<=pending_pc; tn<=pending_pred; tfault<=i_rsp_error;end
                end
            end
            if(fetch_pop) begin
                iv<=1;if(!QUEUE_DATA)begin ii<=fi; ip<=fp; inext<=fn; ifault<=ffault;end
            end else if(id_fire) iv<=0;
            if(id_fire&&!flush) begin
                xv<=1;if(!QUEUE_DATA)begin xi<=ii; xp<=ip; xpred<=inext; xfault<=ifault;end
                if(!OPERAND_HOLD)begin
                    xa<=ii[19:15]==0?0:(wb_forward&&wrd==ii[19:15]?wresult:register_a);
                    xb<=ii[24:20]==0?0:(wb_forward&&wrd==ii[24:20]?wresult:register_b);
                end
            end else if(ex_fire) xv<=0;
            if(mem_leave) begin
                wv<=1; wi<=mi; wp<=mp; wnext<=mnext; wresult<=mem_result; wrd<=mrd;
                wwr<=mwr; wsys<=msys; wfault<=mem_fault||system_fault;
                wcause<=response_fault?(mload?5:7):mfault?mcause:system_cause;
                wtval<=response_fault?maddr:mfault?mtval:system_tval;
                wmret<=system_mret;wa<=ma;mv<=0;
            end
            if(ex_fire) begin
                mv<=1; msent<=0; mdone<=0;
            end
            // A vacant/departing MEM slot has no live payload to preserve.
            // A stalled EX may populate dead data, but only ex_fire sets mv.
            // This removes branch legality and operand-dependent exceptions
            // from the clock enables of address/cause/next-PC registers.
            if(mem_space) begin
                mi<=xi; mp<=xp; mnext<=npc; mresult<=is_multiply?multiply_result:result; mrd<=rd; mwr<=xwr;
                mload<=xld&&!xfault&&!xtrap; mstore<=xst&&!xfault&&!xtrap; msys<=xsys;
                mfault<=xfault||xtrap; mcause<=xfault?1:ec; mtval<=xfault?xp:et; ma<=a;
                maddr<=addr; mwd<=wd; mbe<=be;
            end
            if(d_valid&&d_ready) msent<=1;
            // A returning operation may leave MEM while a new EX operation
            // replaces it. Never overwrite that new operation with old data.
            if(data_complete&&!return_now) begin
                mdone<=1; if(mload) mresult<=loaded;
                if(d_rsp_error) begin mfault<=1; mcause<=mload?5:7; mtval<=maddr; end
            end
            // A held EX instruction must retain forwarded operands after WB/MEM leave.
            if(OPERAND_HOLD)begin
                // A killed or departing EX slot has no live operand state.
                // Updating it freely removes branch resolution from its CE;
                // a newly accepted ID instruction always owns both operands.
                if(id_fire)begin
                    xa<=ii[19:15]==0?0:(wb_forward&&wrd==ii[19:15]?wresult:register_a);
                    xb<=ii[24:20]==0?0:(wb_forward&&wrd==ii[24:20]?wresult:register_b);
                end else if(xv)begin xa<=a;xb<=b;end
            end else if(xv&&!ex_fire) begin xa<=a; xb<=b; end
            if(flush) begin
                fetch_pc<=target; fv<=0; qv<=0; tv<=0; iv<=0; xv<=0;
                if(i_valid&&i_ready || pending&&!(i_rsp_valid&&i_rsp_ready)) stale<=1;
                if(csr_redirect) begin mv<=0; wv<=0; end
            end
        end
    end
endmodule
