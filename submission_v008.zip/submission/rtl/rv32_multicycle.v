module rv32_multicycle #(parameter CSR_ENABLE=0)(
    input wire clk, reset,
    output wire i_valid, input wire i_ready, output wire [31:0] i_addr,
    input wire i_rsp_valid, output wire i_rsp_ready, input wire [31:0] i_rsp_data, input wire i_rsp_error,
    output wire d_valid, input wire d_ready, output wire [31:0] d_addr, d_wdata,
    output wire d_write, output wire [3:0] d_strobe,
    input wire d_rsp_valid, output wire d_rsp_ready, input wire [31:0] d_rsp_data, input wire d_rsp_error,
    input wire timer_irq, software_irq, external_irq,
    output reg halted=0, output reg trace_valid=0,
    output reg [31:0] trace_pc=0, trace_insn=0, trace_data=0, trace_cause=0,
    output reg [4:0] trace_rd=0, output reg trace_trap=0,
    output wire [63:0] cycles, retired,
    output wire [31:0] debug_if_pc, debug_id_pc, debug_ex_pc, debug_mem_pc, debug_wb_pc,
    output wire [4:0] debug_valid, output wire debug_stall, debug_flush,
    output wire [31:0] branch_count, mispredict_count, stall_count
);
    localparam FETCH=0,FETCH_WAIT=1,EXECUTE=2,MEM_REQ=3,MEM_WAIT=4,COMMIT=5;
    reg [2:0] state=FETCH;
    reg [31:0] pc=0, insn=0, regs[0:31];
    reg [31:0] value=0, nextpc=0, fault_cause=0, fault_tval=0;
    reg fault=0;
    wire [4:0] rs1,rs2,rd;
    wire use1,use2,wr,ld,st,sys,exec_trap;
    wire [31:0] result,npc,addr,wd,ec,et;
    wire [3:0] be;
    wire [31:0] a=rs1==0?0:regs[rs1], b=rs2==0?0:regs[rs2];
    rv32_execute execute(insn,pc,a,b,rs1,rs2,rd,use1,use2,wr,ld,st,sys,result,npc,addr,wd,be,exec_trap,ec,et);
    wire [31:0] csr_read, csr_target, csr_cause;
    wire csr_redirect, csr_exception, csr_halt;
    rv32_csr #(.ENABLE(CSR_ENABLE)) csr(clk,reset,state==COMMIT,sys,fault,
        insn,pc,nextpc,a,fault_cause,fault_tval,timer_irq,software_irq,external_irq,
        csr_read,csr_redirect,csr_exception,csr_halt,csr_target,csr_cause,cycles,retired,1'b0);
    wire [31:0] shifted=d_rsp_data>>(addr[1:0]*8);
    function [31:0] load_value;
        input [31:0] data; input [2:0] size;
        begin case(size)
            0: load_value={{24{data[7]}},data[7:0]};
            1: load_value={{16{data[15]}},data[15:0]};
            2: load_value=data;
            4: load_value={24'b0,data[7:0]};
            5: load_value={16'b0,data[15:0]};
            default: load_value=0;
        endcase end
    endfunction
    assign i_valid=!reset&&state==FETCH&&!halted; assign i_addr=pc; assign i_rsp_ready=state==FETCH_WAIT;
    assign d_valid=!reset&&state==MEM_REQ; assign d_addr=addr; assign d_wdata=wd;
    assign d_write=st; assign d_strobe=be; assign d_rsp_ready=state==MEM_WAIT;
    assign debug_if_pc=pc; assign debug_id_pc=pc; assign debug_ex_pc=pc;
    assign debug_mem_pc=pc; assign debug_wb_pc=pc;
    assign debug_valid={state==COMMIT,state==MEM_WAIT,state==EXECUTE,state==FETCH_WAIT,state==FETCH};
    assign debug_stall=state==MEM_WAIT; assign debug_flush=csr_redirect;
    assign branch_count=0; assign mispredict_count=0; assign stall_count=0;
    integer j;
    initial for(j=0;j<32;j=j+1) regs[j]=0;
    always @(posedge clk) begin
        trace_valid<=0;
        if(reset) begin
            state<=FETCH; pc<=0; insn<=0; fault<=0; halted<=0;
            trace_trap<=0; for(j=0;j<32;j=j+1) regs[j]<=0;
        end else if(!halted) case(state)
            FETCH: if(i_ready) state<=FETCH_WAIT;
            FETCH_WAIT: if(i_rsp_valid) begin
                insn<=i_rsp_data; fault<=i_rsp_error; fault_cause<=1; fault_tval<=pc; state<=EXECUTE;
            end
            EXECUTE: begin
                value<=result; nextpc<=npc;
                if(!fault && exec_trap) begin fault<=1; fault_cause<=ec; fault_tval<=et; end
                if(!fault && !exec_trap && (ld||st)) state<=MEM_REQ; else state<=COMMIT;
            end
            MEM_REQ: if(d_ready) state<=MEM_WAIT;
            MEM_WAIT: if(d_rsp_valid) begin
                if(ld) value<=load_value(shifted,insn[14:12]);
                if(d_rsp_error) begin fault<=1; fault_cause<=ld?5:7; fault_tval<=addr; end
                state<=COMMIT;
            end
            COMMIT: begin
                trace_valid<=1; trace_pc<=pc; trace_insn<=insn;
                trace_trap<=csr_exception; trace_cause<=csr_cause;
                trace_rd<=wr&&!csr_exception?rd:0;
                trace_data<=sys&&insn[14:12]!=0?csr_read:value;
                if(wr && rd!=0 && !csr_exception) regs[rd]<=sys?csr_read:value;
                pc<=csr_redirect?csr_target:nextpc; halted<=csr_halt; state<=FETCH; fault<=0;
            end
            default: state<=FETCH;
        endcase
    end
endmodule
