// Static instruction checks only. No CSR state, IRQ, target or timer sampling.
// The pipeline registers these results before WB; the multicycle/default CSR
// can use the same decoder combinationally without changing its interface.
module rv32_system_decode #(parameter ENABLE=1)(
    input wire system,input wire [31:0] insn,pc,
    output reg fault,output reg [31:0] cause,tval,output wire mret
);
    wire [11:0] addr=insn[31:20];
    wire csr_op=system&&insn[14:12]!=0;
    wire csr_write=csr_op&&(insn[13:12]==1||insn[19:15]!=0);
    reg known;
    assign mret=insn==32'h30200073;
    always @* begin
        known=1;
        case(addr)
            12'h300,12'h301,12'h304,12'h305,12'h340,12'h341,12'h342,12'h343,12'h344,
            12'h320,12'hb00,12'hc00,12'hb80,12'hc80,12'hb02,12'hc02,12'hb82,12'hc82,
            12'h310,12'hf11,12'hf12,12'hf13,12'hf14,12'hf15: begin end
            default:known=0;
        endcase
        fault=0;cause=0;tval=0;
        if(system) begin
            if((csr_op&&(!ENABLE||!known||(csr_write&&addr[11:10]==3)))||
                (!ENABLE&&!csr_op&&insn!=32'h00000073&&insn!=32'h00100073)) begin
                fault=1;cause=2;tval=insn;
            end else if(insn==32'h00000073) begin fault=1;cause=11;end
            else if(insn==32'h00100073) begin fault=1;cause=3;tval=pc;end
        end
    end
endmodule
