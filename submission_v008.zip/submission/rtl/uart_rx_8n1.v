module uart_rx_8n1 #(parameter integer CLKS_PER_BIT = 234)(
    input wire clk, input wire reset, input wire serial_in,
    output reg [7:0] data = 0, output reg valid = 0
);
    localparam integer TIMER_BITS = (CLKS_PER_BIT < 2) ? 1 : $clog2(CLKS_PER_BIT);
    localparam IDLE=0, START=1, DATA=2, STOP=3, WAIT_HIGH=4;
    reg meta = 1, synced = 1;
    reg [2:0] state = IDLE, bit_index = 0;
    reg [TIMER_BITS-1:0] timer = 0;
    always @(posedge clk) begin
        if (reset) begin meta <= 1; synced <= 1; end
        else begin meta <= serial_in; synced <= meta; end
    end
    always @(posedge clk) begin
        valid <= 0;
        if (reset) begin
            state <= IDLE; timer <= 0; bit_index <= 0; data <= 0;
        end else case (state)
            IDLE: if (!synced) begin
                timer <= CLKS_PER_BIT/2-1; state <= START;
            end
            START: if (timer != 0) timer <= timer-1'b1;
                else if (synced) state <= IDLE;
                else begin timer <= CLKS_PER_BIT-1; bit_index <= 0; state <= DATA; end
            DATA: if (timer != 0) timer <= timer-1'b1;
                else begin
                    data[bit_index] <= synced; timer <= CLKS_PER_BIT-1;
                    if (bit_index == 7) state <= STOP;
                    else bit_index <= bit_index+1'b1;
                end
            STOP: if (timer != 0) timer <= timer-1'b1;
                else if (synced) begin valid <= 1; state <= IDLE; end
                else state <= WAIT_HIGH; // Bad stop bit/break: discard this frame.
            WAIT_HIGH: if (synced) state <= IDLE;
            default: state <= IDLE;
        endcase
    end
endmodule
