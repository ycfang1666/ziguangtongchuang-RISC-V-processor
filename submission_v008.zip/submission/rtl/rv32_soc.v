module rv32_soc #(
    parameter MULTICYCLE=0, CSR_ENABLE=1, PREDICT=0, CACHE=0, DEBUG=0,
    parameter ICACHE=CACHE, DCACHE=CACHE, CACHE_FAST=1, STREAM_FETCH=1, ZMMUL=1,
    parameter FAST_LOAD=1, MUL_EARLY=1, FAST_DATA=1, LOAD_BYPASS=2, BTB_BITS=6, BTB_COMPACT=1, INDIRECT=1,
    parameter OPERAND_HOLD=1,CACHE_STATS_PIPE=1,CACHE_LRU_PIPE=1,EARLY_MEMORY=0,FWD_SELECT=0,DELAY_BRANCH=0,BHT_BITS=0,GSHARE=0,RAS_BITS=0,RELAX_FORWARD=0,RF_RAM=0,RAM_POST=0,PC_ANCHOR=0,CACHE_PAYLOAD=0,
    parameter UART_DIV=234, WAIT_CYCLES=0,
    parameter ROM_FILE="firmware.hex"
)(input wire clk,rstn,uart_rx, output wire uart_tx, output reg led=0);
    reg [7:0] startup=0;
    reg reset_meta=0,reset_sync=0;
    always @(posedge clk) begin
        reset_meta<=!rstn; reset_sync<=reset_meta;
        if(startup!=255) startup<=startup+1'b1;
    end
    // core_rstn already has synchronous release. Mask requests immediately on
    // lock loss, including the first returning clock edges before reset_sync.
    wire reset=!rstn||reset_sync||(startup!=255);
    wire iv,ir,irv,irr,ire,dv,dr,drv,drr,dre,dw;
    wire [31:0] ia,idata,da,dwd,ddata; wire [3:0] ds;
    wire halted,trace_valid,trace_trap; wire [4:0] trace_rd;
    wire [31:0] trace_pc,trace_insn,trace_data,trace_cause;
    wire [63:0] cpu_cycles,cpu_retired;
    wire [31:0] if_pc,id_pc,ex_pc,mem_pc,wb_pc,branches,mispredicts,stalls;
    wire [4:0] stage_valid; wire pipe_stall,pipe_flush;
    wire rx_valid,tx_busy;
    reg [239:0] debug_sample=0 /* synthesis PAP_MARK_DEBUG="true" syn_preserve=1 */;
    generate if(DEBUG) begin:debug_capture
        // Observer-only register bank. The ILA sees this sample one edge later.
        always @(posedge clk) debug_sample <= {rx_valid,reset,ire,dre,ds,dw,halted,trace_trap,trace_valid,pipe_flush,pipe_stall,drr,drv,dr,dv,irr,irv,ir,iv,trace_rd,stage_valid,trace_data,da,trace_insn,trace_pc,wb_pc[15:0],mem_pc[15:0],ex_pc[15:0],id_pc[15:0],if_pc[15:0]};
    end endgenerate
    wire timer_irq,software_irq,external_irq;
    generate if(MULTICYCLE) begin:baseline
        rv32_multicycle #(.CSR_ENABLE(CSR_ENABLE)) cpu(
            clk,reset,iv,ir,ia,irv,irr,idata,ire,dv,dr,da,dwd,dw,ds,drv,drr,ddata,dre,
            timer_irq,software_irq,external_irq,halted,trace_valid,trace_pc,trace_insn,trace_data,trace_cause,
            trace_rd,trace_trap,cpu_cycles,cpu_retired,if_pc,id_pc,ex_pc,mem_pc,wb_pc,stage_valid,pipe_stall,pipe_flush,
            branches,mispredicts,stalls);
    end else begin:pipeline
        rv32_pipeline #(.CSR_ENABLE(CSR_ENABLE),.PREDICT(PREDICT),.STREAM_FETCH(STREAM_FETCH),.ZMMUL(ZMMUL),
            .FAST_LOAD(FAST_LOAD),.MUL_EARLY(MUL_EARLY),.LOAD_BYPASS(LOAD_BYPASS),.BTB_BITS(BTB_BITS),.BTB_COMPACT(BTB_COMPACT),.INDIRECT(INDIRECT),
            .OPERAND_HOLD(OPERAND_HOLD),.EARLY_MEMORY(EARLY_MEMORY),.FWD_SELECT(FWD_SELECT),.DELAY_BRANCH(DELAY_BRANCH),.BHT_BITS(BHT_BITS),.GSHARE(GSHARE),.RAS_BITS(RAS_BITS),.RELAX_FORWARD(RELAX_FORWARD),.RF_RAM(RF_RAM),.PC_ANCHOR(PC_ANCHOR)) cpu(
            clk,reset,iv,ir,ia,irv,irr,idata,ire,dv,dr,da,dwd,dw,ds,drv,drr,ddata,dre,
            timer_irq,software_irq,external_irq,halted,trace_valid,trace_pc,trace_insn,trace_data,trace_cause,
            trace_rd,trace_trap,cpu_cycles,cpu_retired,if_pc,id_pc,ex_pc,mem_pc,wb_pc,stage_valid,pipe_stall,pipe_flush,
            branches,mispredicts,stalls);
    end endgenerate
    wire biv,bir,birv,birr,bire,bdv,bdr,bdrv,bdrr,bdre,bdw;
    wire [31:0] bia,biwd,bidata,bda,bdwd,bddata; wire [3:0] bis,bds;
    wire [2:0] bib,bdb; wire bilast,bdlast,biwrite;
    wire [31:0] ihits,imisses,dhits,dmisses;
    rv32_cache #(.ENABLE(ICACHE),.READ_ONLY(1),.FAST_HIT(CACHE_FAST),.COUNT_PIPE(CACHE_STATS_PIPE),.LRU_PIPE(CACHE_LRU_PIPE),.PAYLOAD_RELAX(CACHE_PAYLOAD)) icache(
        clk,reset,iv,ir,ia,32'b0,1'b0,4'b0,irv,irr,idata,ire,
        biv,bir,bia,biwd,biwrite,bis,bib,birv,birr,bidata,bire,bilast,ihits,imisses);
    rv32_cache #(.POST_RAM_WRITES(RAM_POST),.ENABLE(DCACHE),.FAST_HIT(CACHE_FAST),.COUNT_PIPE(CACHE_STATS_PIPE),.LRU_PIPE(CACHE_LRU_PIPE),.PAYLOAD_RELAX(CACHE_PAYLOAD)) dcache(
        clk,reset,dv,dr,da,dwd,dw,ds,drv,drr,ddata,dre,
        bdv,bdr,bda,bdwd,bdw,bds,bdb,bdrv,bdrr,bddata,bdre,bdlast,dhits,dmisses);
    wire [31:0] rom_d_data,ram_data;
    rv32_instruction_port #(.ROM_FILE(ROM_FILE),.WAIT_CYCLES(WAIT_CYCLES)) instruction_port(
        clk,reset,biv,bir,bia,bib,birv,birr,bidata,bire,bilast);
    wire [7:0] rx_byte;
    reg tx_start=0; reg [7:0] tx_byte=0;
    uart_rx_8n1 #(.CLKS_PER_BIT(UART_DIV)) rx(clk,reset,uart_rx,rx_byte,rx_valid);
    uart_tx_8n1 #(.CLKS_PER_BIT(UART_DIV)) tx(clk,reset,tx_start,tx_byte,uart_tx,tx_busy);
    reg [7:0] fifo[0:15]; reg [3:0] rptr=0,wptr=0;
    reg [4:0] count=0; reg overflow=0;
    reg [63:0] ticks=0,compare_value=64'hffffffffffffffff;
    reg soft_irq=0,rx_irq_enable=0;
    // MTIP may reflect the comparator a cycle later; it is a pending level,
    // not a pulse. Register the wide comparison before CSR/LSU controls.
    reg timer_pending=0;
    always @(posedge clk)if(reset)timer_pending<=0;else timer_pending<=ticks>=compare_value;
    assign timer_irq=timer_pending; assign software_irq=soft_irq;
    assign external_irq=rx_irq_enable&&count!=0;
    reg dbusy=0,dbus_rsp=0,derr=0,dlast=0;
    reg [31:0] dptr=0,dwrite_data=0,drdata=0; reg dwrite=0;
    reg [3:0] dbyte_enable=0; reg [2:0] dleft=0;
    reg [15:0] dwait=0;
    reg dmemory_pending=0;
    wire service=dbusy&&!dbus_rsp&&dwait==0;
    wire profile_select=dptr[31:6]==(32'h20002100>>6);
    wire [31:0] profile_data;
    rv32_profile profile(
        clk,reset,service&&!dwrite&&profile_select&&dptr[5:2]==0,dptr[5:2],
        ticks,cpu_cycles,cpu_retired,branches,mispredicts,stalls,ihits,imisses,dhits,dmisses,
        iv&&ir,irv&&irr,dv&&dr,drv&&drr,profile_data);
    wire ram_select=dptr[31:16]==16'h1000,rom_select=dptr[31:16]==0;
    wire memory_enable=service&&!dmemory_pending;
    wire incoming_memory=bda[31:16]==0||bda[31:16]==16'h1000;
    wire memory_ready,memory_valid,memory_error,memory_last,memory_busy;
    wire [31:0] memory_data;
    generate if(FAST_DATA)begin:fast_memory
        rv32_data_memory #(.ROM_FILE(ROM_FILE),.WAIT_CYCLES(WAIT_CYCLES)) port(
            clk,reset,bdv&&incoming_memory&&!dbusy,memory_ready,bda,bdwd,bdw,bds,bdb,
            memory_valid,bdrr&&!dbusy,memory_data,memory_error,memory_last,memory_busy);
        assign ram_data=0;assign rom_d_data=0;
    end else begin:legacy_memory
        rv32_rom #(.FILE(ROM_FILE)) data_rom(clk,memory_enable&&rom_select,dptr[15:2],rom_d_data);
        rv32_ram data_ram(clk,memory_enable&&ram_select,dwrite,dptr[15:2],dwrite_data,dbyte_enable,ram_data);
        assign memory_ready=0;assign memory_valid=0;assign memory_data=0;
        assign memory_error=0;assign memory_last=0;assign memory_busy=0;
    end endgenerate
    wire pop_rx=service&&!dwrite&&dptr==32'h20000008&&count!=0;
    wire push_rx=rx_valid&&(count<16||pop_rx);
    assign bdr=FAST_DATA&&incoming_memory?memory_ready&&!dbusy:!dbusy&&!memory_busy;
    assign bdrv=memory_busy?memory_valid:dbus_rsp;
    assign bddata=memory_busy?memory_data:drdata;
    assign bdre=memory_busy?memory_error:derr;assign bdlast=memory_busy?memory_last:dlast;
    always @(posedge clk) begin
        tx_start<=0;
        if(reset) begin
            dbusy<=0; dbus_rsp<=0; led<=0; ticks<=0; compare_value<=64'hffffffffffffffff;
            count<=0; rptr<=0; wptr<=0; overflow<=0; soft_irq<=0; rx_irq_enable<=0; dmemory_pending<=0;
        end else begin
            ticks<=ticks+1;
            if(push_rx) begin fifo[wptr]<=rx_byte; wptr<=wptr+1'b1; end
            if(rx_valid&&!push_rx) overflow<=1;
            if(pop_rx) rptr<=rptr+1'b1;
            case({push_rx,pop_rx}) 2'b10:count<=count+1'b1; 2'b01:count<=count-1'b1; default:begin end endcase
            if(bdv&&bdr&&(!FAST_DATA||!incoming_memory)) begin
                dbusy<=1; dptr<=bda; dleft<=bdb; dwrite<=bdw; dwrite_data<=bdwd; dbyte_enable<=bds; dwait<=WAIT_CYCLES;
            end
            if(dbusy&&!dbus_rsp && dwait!=0) dwait<=dwait-1'b1;
            if(service) begin
                derr<=0; drdata<=0; dlast<=dleft==1;
                // TX can hold a request until transmitter accepts it. Each write starts once.
                if((ram_select||rom_select)&&!dmemory_pending) dmemory_pending<=1;
                else if(dwrite&&dptr==32'h20000000&&(tx_busy||tx_start)) begin end
                else begin
                    dbus_rsp<=1;
                    dmemory_pending<=0;
                    if(ram_select) drdata<=ram_data;
                    else if(rom_select) begin drdata<=rom_d_data; if(dwrite) derr<=1; end
                    else if(profile_select) begin
                        drdata<=profile_data;
                        if(dwrite||dptr[5:2]>14) derr<=1;
                    end else case({dptr[31:2],2'b0})
                        32'h20000000: if(dwrite&&dbyte_enable[0]) begin tx_start<=1; tx_byte<=dwrite_data[7:0]; end
                        32'h20000004: drdata<={24'b0,overflow,count!=0,tx_busy||tx_start,5'b0};
                        32'h20000008: drdata<=count!=0?{24'b0,fifo[rptr]}:32'hffffffff;
                        32'h2000000c: begin drdata<={30'b0,rx_irq_enable,overflow}; if(dwrite&&dbyte_enable[0]) begin
                            if(dwrite_data[0]) overflow<=0; rx_irq_enable<=dwrite_data[1]; end end
                        32'h20001000: begin drdata<={31'b0,led}; if(dwrite&&dbyte_enable[0]) led<=dwrite_data[0]; end
                        32'h20002000: drdata<=ticks[31:0];
                        32'h20002004: drdata<=ticks[63:32];
                        32'h20002008: begin drdata<=compare_value[31:0]; if(dwrite) compare_value[31:0]<=dwrite_data; end
                        32'h2000200c: begin drdata<=compare_value[63:32]; if(dwrite) compare_value[63:32]<=dwrite_data; end
                        32'h20002010: begin drdata<={31'b0,soft_irq}; if(dwrite) soft_irq<=dwrite_data[0]; end
                        32'h20002020: drdata<=cpu_cycles[31:0]; 32'h20002024: drdata<=cpu_cycles[63:32];
                        32'h20002028: drdata<=cpu_retired[31:0]; 32'h2000202c: drdata<=cpu_retired[63:32];
                        32'h20002030: drdata<=branches; 32'h20002034: drdata<=mispredicts;
                        32'h20002038: drdata<=stalls;
                        32'h20002040: drdata<=ihits; 32'h20002044: drdata<=imisses;
                        32'h20002048: drdata<=dhits; 32'h2000204c: drdata<=dmisses;
                        32'h20002050: begin drdata<=(ICACHE?1:0)|(DCACHE?2:0); if(dwrite) derr<=1; end
                        default: derr<=1;
                    endcase
                end
            end
            if(dbus_rsp&&bdrr) begin
                dbus_rsp<=0;
                if(dleft==1) dbusy<=0;
                else begin dptr<=dptr+4; dleft<=dleft-1'b1; dwait<=WAIT_CYCLES; end
            end
        end
    end
endmodule
