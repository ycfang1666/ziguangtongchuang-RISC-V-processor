// One-cycle synchronous ROM/RAM adapter. Each burst beat accesses the memory
// on request acceptance (or the preceding response handshake), then holds
// the registered output until consumption. MMIO is decoded separately.
module rv32_data_memory #(parameter ROM_FILE="firmware.hex", WAIT_CYCLES=0)(
    input wire clk,reset,
    input wire req_valid,output wire req_ready,input wire [31:0] req_addr,req_wdata,
    input wire req_write,input wire [3:0] req_strobe,input wire [2:0] req_beats,
    output wire rsp_valid,input wire rsp_ready,output wire [31:0] rsp_data,
    output reg rsp_error=0,rsp_last=0,output reg busy=0
);
    reg valid=0,writing=0;reg [31:0] address=0,wdata=0;
    reg [3:0] strobe=0;reg [2:0] remaining=0;reg [15:0] wait_left=0;
    assign req_ready=!reset&&(!busy||(valid&&rsp_ready&&rsp_last));
    assign rsp_valid=!reset&&valid;
    wire accept=req_valid&&req_ready,consume=rsp_valid&&rsp_ready;
    wire next_beat=consume&&!rsp_last;
    wire access_now=!reset&&((WAIT_CYCLES==0&&(accept||next_beat))||(busy&&!valid&&wait_left==1));
    wire [31:0] access_address=accept?req_addr:next_beat?address+32'd4:address;
    wire [2:0] access_remaining=accept?req_beats:next_beat?remaining-3'd1:remaining;
    wire access_write=accept?req_write:writing;
    wire [31:0] access_wdata=accept?req_wdata:wdata;
    wire [3:0] access_strobe=accept?req_strobe:strobe;
    wire ram_select=access_address[31:16]==16'h1000,rom_select=access_address[31:16]==0;
    wire [31:0] ram_data,rom_data;
    rv32_ram data_ram(clk,access_now&&ram_select,access_write,access_address[15:2],access_wdata,access_strobe,ram_data);
    rv32_rom #(.FILE(ROM_FILE)) data_rom(clk,access_now&&rom_select,access_address[15:2],rom_data);
    assign rsp_data=writing ? 0 : address[31:16]==16'h1000 ? ram_data : address[31:16]==0 ? rom_data : 0;
    always @(posedge clk)begin
        if(reset)begin busy<=0;valid<=0;address<=0;remaining<=0;wait_left<=0;rsp_error<=0;rsp_last<=0;end
        else begin
            if(consume)begin
                valid<=0;
                if(rsp_last)busy<=0;
                else begin address<=address+32'd4;remaining<=remaining-3'd1;wait_left<=WAIT_CYCLES;end
            end
            if(accept)begin
                busy<=1;address<=req_addr;remaining<=req_beats;writing<=req_write;
                wdata<=req_wdata;strobe<=req_strobe;wait_left<=WAIT_CYCLES;
            end
            if(busy&&!valid&&wait_left!=0)wait_left<=wait_left-1'b1;
            if(access_now)begin
                valid<=1;rsp_last<=access_remaining==1;
                rsp_error<=!(ram_select||rom_select)||(rom_select&&access_write);
            end
        end
    end
endmodule
