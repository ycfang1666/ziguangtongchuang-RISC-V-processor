module rv32_cpu_top(input wire clk,rstn,uart_rx,output wire uart_tx,led);
    rv32_pll_system #(.ROM_FILE("firmware/firmware.hex"),.CLOCK_HZ(180000000),.ICACHE(1),.DCACHE(1),.CACHE_FAST(1),.STREAM_FETCH(1),.BTB_BITS(6),.LOAD_BYPASS(0),.OPERAND_HOLD(1),.EARLY_MEMORY(1),.MUL_EARLY(2),.FWD_SELECT(1),.DELAY_BRANCH(0),.BHT_BITS(0),.GSHARE(0),.RAS_BITS(0),.RELAX_FORWARD(1),.RF_RAM(1),.RAM_POST(1),.PC_ANCHOR(1),.CACHE_PAYLOAD(1)) system(clk,rstn,uart_rx,uart_tx,led);
endmodule
