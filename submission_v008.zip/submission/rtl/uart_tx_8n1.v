module uart_tx_8n1 #(parameter integer CLKS_PER_BIT = 234)(
    input wire clk, input wire reset, input wire start, input wire [7:0] data,
    output reg serial_out = 1, output reg busy = 0
);
    localparam integer TIMER_BITS = (CLKS_PER_BIT < 2) ? 1 : $clog2(CLKS_PER_BIT);
    reg [TIMER_BITS-1:0] timer = 0;
    reg [9:0] frame = 10'h3ff;
    reg [3:0] bit_index = 0;
    always @(posedge clk) begin
        if (reset) begin
            serial_out <= 1; busy <= 0; timer <= 0; frame <= 10'h3ff; bit_index <= 0;
        end else if (!busy) begin
            if (start) begin
                frame <= {1'b1, data, 1'b0}; serial_out <= 0;
                busy <= 1; timer <= CLKS_PER_BIT-1; bit_index <= 0;
            end
        end else if (timer != 0) timer <= timer-1'b1;
        else if (bit_index == 9) begin busy <= 0; serial_out <= 1; end
        else begin
            frame <= {1'b1, frame[9:1]}; serial_out <= frame[1];
            bit_index <= bit_index+1'b1; timer <= CLKS_PER_BIT-1;
        end
    end
endmodule
