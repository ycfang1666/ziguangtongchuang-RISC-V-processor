// GPLL internal CLKOUTF feedback: Fvco=27MHz/1 * 2 * 20=1080MHz.
// 48MHz uses 864MHz; 51MHz uses 918MHz/18. GPLL VCO range: 600..1200MHz.
module rv32_pll_clock #(parameter CLOCK_HZ=36000000)(
    input wire ref_clk,rstn,
    output wire core_clk,core_rstn,locked
);
    localparam FB_DIV=CLOCK_HZ==48000000||CLOCK_HZ==72000000||CLOCK_HZ==144000000?16:
        CLOCK_HZ==51000000||CLOCK_HZ==153000000?17:CLOCK_HZ==57000000||CLOCK_HZ==171000000?19:
        CLOCK_HZ==63000000||CLOCK_HZ==126000000||CLOCK_HZ==189000000?21:
        CLOCK_HZ==66000000||CLOCK_HZ==99000000||CLOCK_HZ==132000000||CLOCK_HZ==198000000?22:
        CLOCK_HZ==81000000||CLOCK_HZ==162000000?18:20;
    localparam OUT_DIV=(27000000*2*FB_DIV)/CLOCK_HZ;
    reg [7:0] power_on=0;
    always @(posedge ref_clk or negedge rstn)
        if(!rstn) power_on<=0;
        else power_on<={power_on[6:0],1'b1};
    wire pll_reset=!rstn||!power_on[7];
    GTP_GPLL #(
        .CLKIN_FREQ(27.0),.LOCK_MODE(0),.STATIC_RATIOI(1),.STATIC_RATIOM(2),
        .STATIC_RATIOF(FB_DIV),.STATIC_RATIO0(OUT_DIV),
        .STATIC_DUTYF(FB_DIV),.STATIC_DUTY0(OUT_DIV),
        .STATIC_RATIO1(128),.STATIC_RATIO2(128),.STATIC_RATIO3(128),
        .STATIC_RATIO4(128),.STATIC_RATIO5(128),.STATIC_RATIO6(128),
        .STATIC_DUTY1(128),.STATIC_DUTY2(128),.STATIC_DUTY3(128),
        .STATIC_DUTY4(128),.STATIC_DUTY5(128),.STATIC_DUTY6(128),
        .INTERNAL_FB("CLKOUTF"),.EXTERNAL_FB("DISABLE"),.SSC_MODE("DISABLE")
    ) u_pll(
        .CLKOUT0(core_clk),.CLKOUT0N(),.CLKOUT1(),.CLKOUT1N(),.CLKOUT2(),.CLKOUT2N(),
        .CLKOUT3(),.CLKOUT3N(),.CLKOUT4(),.CLKOUT5(),.CLKOUT6(),.CLKOUTF(),.CLKOUTFN(),
        .DPS_DONE(),.APB_RDATA(),.APB_READY(),.LOCK(locked),.CLKIN1(ref_clk),.CLKIN2(1'b0),
        .CLKFB(1'b0),.CLKIN_SEL(1'b0),.PLL_PWD(1'b0),.RST(pll_reset),
        .DPS_CLK(1'b0),.DPS_EN(1'b0),.DPS_DIR(1'b0),
        .CLKOUT0_SYN(1'b0),.CLKOUT1_SYN(1'b0),.CLKOUT2_SYN(1'b0),
        .CLKOUT3_SYN(1'b0),.CLKOUT4_SYN(1'b0),.CLKOUT5_SYN(1'b0),
        .CLKOUT6_SYN(1'b0),.CLKOUTF_SYN(1'b0),
        .APB_CLK(1'b0),.APB_RST_N(1'b0),.APB_ADDR(5'b0),
        .APB_SEL(1'b0),.APB_EN(1'b0),.APB_WRITE(1'b0),.APB_WDATA(16'b0)
    );
    // Assert on external reset or loss of lock; release only on core edges.
    reg [2:0] release_reset=0;
    always @(posedge core_clk or negedge rstn or negedge locked)
        if(!rstn||!locked) release_reset<=0;
        else release_reset<={release_reset[1:0],1'b1};
    assign core_rstn=release_reset[2];
endmodule
