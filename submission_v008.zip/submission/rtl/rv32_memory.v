// Isolated synchronous templates: no array reset, one write port per byte lane.
// Keeping the read register outside peripheral multiplexers enables DRM inference.
module rv32_rom #(parameter FILE="firmware.hex")(
    input wire clk,enable,input wire [13:0] address,output reg [31:0] data
);
    reg [31:0] memory[0:16383];
    initial $readmemh(FILE,memory);
    always @(posedge clk) if(enable) data<=memory[address];
endmodule

module rv32_ram #(parameter ADDRESS_BITS=14)(
    input wire clk,enable,write,input wire [ADDRESS_BITS-1:0] address,
    input wire [31:0] wdata,input wire [3:0] strobe,output reg [31:0] data
);
    reg [7:0] lane0[0:(1<<ADDRESS_BITS)-1],lane1[0:(1<<ADDRESS_BITS)-1];
    reg [7:0] lane2[0:(1<<ADDRESS_BITS)-1],lane3[0:(1<<ADDRESS_BITS)-1];
    always @(posedge clk) if(enable) begin
        data<={lane3[address],lane2[address],lane1[address],lane0[address]};
        if(write) begin
            if(strobe[0]) lane0[address]<=wdata[7:0];
            if(strobe[1]) lane1[address]<=wdata[15:8];
            if(strobe[2]) lane2[address]<=wdata[23:16];
            if(strobe[3]) lane3[address]<=wdata[31:24];
        end
    end
endmodule
