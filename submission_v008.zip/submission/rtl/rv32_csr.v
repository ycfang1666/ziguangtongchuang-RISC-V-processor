// M-only execution environment; unsupported modes/features read as zero.
module rv32_csr #(parameter ENABLE=1, PREDECODE=0)(
    input wire clk, reset,
    input wire commit, system, fault,
    input wire [31:0] insn, pc, next_pc, operand, fault_cause, fault_tval,
    input wire timer_irq, software_irq, external_irq,
    output reg [31:0] read_data,
    output reg redirect, exception, halt,
    output reg [31:0] target, trap_cause,
    output wire [63:0] cycles, retired,
    input wire decoded_mret
);
    reg [31:0] mstatus=32'h1800, mie=0, mtvec=0, mscratch=0, mepc=0, mcause=0, mtval=0;
    reg [63:0] cycle_count=0, instret_count=0;
    reg [31:0] inhibit=0;
    wire [31:0] mip={20'b0,external_irq,3'b0,timer_irq,3'b0,software_irq,3'b0};
    wire [31:0] pending=mip&mie;
    wire [11:0] addr=insn[31:20];
    wire [2:0] f3=insn[14:12];
    wire csr_op=system && f3!=0;
    wire csr_write=csr_op && (f3[1:0]==1 || insn[19:15]!=0);
    wire [31:0] source=f3[2]?{27'b0,insn[19:15]}:operand;
    wire static_fault,static_mret;
    wire [31:0] static_cause,static_tval;
    generate if(!PREDECODE) begin:decode_here
        rv32_system_decode #(.ENABLE(ENABLE)) decode(
            system,insn,pc,static_fault,static_cause,static_tval,static_mret);
    end else begin:decode_in_pipeline
        assign static_fault=0;assign static_cause=0;assign static_tval=0;
        assign static_mret=decoded_mret;
    end endgenerate
    reg [31:0] updated, exception_value;
    assign cycles=cycle_count; assign retired=instret_count;
    always @* begin
        read_data=0;
        case(addr)
            12'h300: read_data=mstatus;
            12'h301: read_data=32'h40000100; // RV32, I only; M denotes multiply, not machine mode.
            12'h304: read_data=mie; 12'h305: read_data=mtvec;
            12'h340: read_data=mscratch; 12'h341: read_data=mepc;
            12'h342: read_data=mcause; 12'h343: read_data=mtval; 12'h344: read_data=mip;
            12'h320: read_data=inhibit;
            12'hb00,12'hc00: read_data=cycle_count[31:0];
            12'hb80,12'hc80: read_data=cycle_count[63:32];
            12'hb02,12'hc02: read_data=instret_count[31:0];
            12'hb82,12'hc82: read_data=instret_count[63:32];
            12'h310,12'hf11,12'hf12,12'hf13,12'hf14,12'hf15: read_data=0;
            default: read_data=0;
        endcase
        case(f3[1:0])
            1: updated=source; 2: updated=read_data|source;
            3: updated=read_data&~source; default: updated=read_data;
        endcase
        redirect=0; exception=0; halt=0; target=next_pc; trap_cause=0; exception_value=0;
        if(commit) begin
            if(fault) begin exception=1; trap_cause=fault_cause; exception_value=fault_tval; end
            else if(system) begin
                if(static_fault) begin exception=1;trap_cause=static_cause;exception_value=static_tval;end
                else if(static_mret) begin redirect=1; target=mepc; end
            end
            if(!exception && !redirect && ENABLE && mstatus[3] && pending!=0) begin
                redirect=1;
                trap_cause=pending[11]?32'h8000000b:pending[3]?32'h80000003:32'h80000007;
            end
            if(exception || trap_cause[31]) begin
                redirect=1; halt=!ENABLE;
                target={mtvec[31:2],2'b0};
                if(trap_cause[31] && mtvec[1:0]==1) target=target+((trap_cause&31)*4);
            end
        end
    end
    always @(posedge clk) begin
        if(reset) begin
            mstatus<=32'h1800; mie<=0; mtvec<=0; mscratch<=0; mepc<=0; mcause<=0; mtval<=0;
            cycle_count<=0; instret_count<=0; inhibit<=0;
        end else begin
            if(!inhibit[0]) cycle_count<=cycle_count+1;
            if(commit && !exception && !inhibit[2]) instret_count<=instret_count+1;
            if(commit && !exception && csr_write && ENABLE) case(addr)
                12'h300: mstatus<=32'h1800|(updated&32'h88);
                12'h304: mie<=updated&32'h888;
                12'h305: mtvec<={updated[31:2],1'b0,updated[1:0]==1};
                12'h340: mscratch<=updated; 12'h341: mepc<=updated&32'hfffffffc;
                12'h342: mcause<=updated; 12'h343: mtval<=updated;
                12'h320: inhibit<=updated&5;
                12'hb00: cycle_count[31:0]<=updated; 12'hb80: cycle_count[63:32]<=updated;
                12'hb02: instret_count[31:0]<=updated; 12'hb82: instret_count[63:32]<=updated;
                default: begin end
            endcase
            if(commit && redirect && (exception || trap_cause[31])) begin
                mepc<=exception?pc:next_pc; mcause<=trap_cause; mtval<=exception_value;
                mstatus[7]<=mstatus[3]; mstatus[3]<=0;
            end else if(commit && !exception && static_mret) begin
                mstatus[3]<=mstatus[7]; mstatus[7]<=1;
            end
        end
    end
endmodule
