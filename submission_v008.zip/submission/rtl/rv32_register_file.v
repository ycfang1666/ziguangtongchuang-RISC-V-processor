// Two asynchronous read ports, one synchronous write port. A validity bitmap
// preserves zero reads after every reset without resetting distributed RAM.
module rv32_register_file #(parameter DISTRIBUTED=0)(
    input wire clk,reset,write_enable,input wire [4:0] write_address,
    input wire [31:0] write_data,input wire [4:0] read_address1,read_address2,
    output wire [31:0] read_data1,read_data2
);
    wire writing=write_enable&&write_address!=0&&!reset;
    generate if(DISTRIBUTED)begin: distributed
        // Replication gives each bank a simple one-write/one-read RAM shape.
        reg [31:0] bank1[0:31] /* synthesis syn_ramstyle="lut_ram" */;
        reg [31:0] bank2[0:31] /* synthesis syn_ramstyle="lut_ram" */;
        reg [31:0] valid=0;
        integer i;
        initial for(i=0;i<32;i=i+1)begin bank1[i]=0;bank2[i]=0;end
        always @(posedge clk)begin
            if(reset)valid<=0;else if(writing)valid[write_address]<=1;
            if(writing)begin bank1[write_address]<=write_data;bank2[write_address]<=write_data;end
        end
        assign read_data1=read_address1!=0&&valid[read_address1]?bank1[read_address1]:32'b0;
        assign read_data2=read_address2!=0&&valid[read_address2]?bank2[read_address2]:32'b0;
    end else begin: flipflops
        reg [31:0] words[0:31];integer i;
        initial for(i=0;i<32;i=i+1)words[i]=0;
        always @(posedge clk)begin
            if(reset)for(i=0;i<32;i=i+1)words[i]<=0;
            else if(writing)words[write_address]<=write_data;
        end
        assign read_data1=read_address1!=0?words[read_address1]:32'b0;
        assign read_data2=read_address2!=0?words[read_address2]:32'b0;
    end endgenerate
endmodule
