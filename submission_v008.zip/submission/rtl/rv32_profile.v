// Reading offset 0 atomically samples all counters. Other offsets stay frozen.
// Wait cycles count outstanding CPU-side requests, including response cycles.
// I/D waits and EX stalls overlap; they are not an additive CPI decomposition.
module rv32_profile(
    input wire clk,reset,sample,
    input wire [3:0] index,
    input wire [63:0] ticks,cycles,retired,
    input wire [31:0] branches,mispredicts,stalls,ihits,imisses,dhits,dmisses,
    input wire i_accept,i_complete,d_accept,d_complete,
    output reg [31:0] data
);
    reg i_pending=0,d_pending=0;
    reg [31:0] i_wait=0,d_wait=0;
    reg [31:0] snapshot[1:14];
    integer n;
    always @(posedge clk) begin
        if(reset) begin
            i_pending<=0; d_pending<=0; i_wait<=0; d_wait<=0;
            for(n=1;n<=14;n=n+1) snapshot[n]<=0;
        end else begin
            // A completion retires the old request; simultaneous acceptance
            // owns the following cycle. Single outstanding, >=1-cycle bus.
            if(i_accept||i_complete) i_pending<=i_accept;
            if(d_accept||d_complete) d_pending<=d_accept;
            if(i_pending) i_wait<=i_wait+1'b1;
            if(d_pending) d_wait<=d_wait+1'b1;
            if(sample) begin
                snapshot[1]<=ticks[63:32];
                snapshot[2]<=cycles[31:0]; snapshot[3]<=cycles[63:32];
                snapshot[4]<=retired[31:0]; snapshot[5]<=retired[63:32];
                snapshot[6]<=branches; snapshot[7]<=mispredicts; snapshot[8]<=stalls;
                snapshot[9]<=ihits; snapshot[10]<=imisses;
                snapshot[11]<=dhits; snapshot[12]<=dmisses;
                snapshot[13]<=i_wait; snapshot[14]<=d_wait;
            end
        end
    end
    always @* begin
        if(index==0) data=ticks[31:0];
        else if(index<=14) data=snapshot[index];
        else data=0;
    end
endmodule
