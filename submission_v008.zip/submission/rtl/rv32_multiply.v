// Zmmul: four 17x17 signed products infer FPGA DSP multipliers. Each
// arithmetic boundary is registered; backpressure holds the finished result.
// Splitting at bit 16 makes the upper-half signedness explicit for MULH/SU/U.
module rv32_multiply #(parameter EARLY_LOW=1, parameter STREAM_PRODUCTS=1)(
    input wire clk, reset, start, consume,
    input wire [31:0] a,b, input wire [1:0] operation,
    output wire busy, ready, output wire [31:0] result
);
    reg [1:0] stage=0,kind=0;
    reg [31:0] p00=0;
    reg signed [33:0] p01=0,p10=0,p11=0;
    reg signed [34:0] cross_sum=0;
    reg [31:0] high_base=0;
    reg [15:0] low_base=0;
    reg [31:0] answer=0;
    wire signed [16:0] alo={1'b0,a[15:0]},blo={1'b0,b[15:0]};
    wire signed [16:0] ahi={(operation==1||operation==2)&&a[31],a[31:16]};
    wire signed [16:0] bhi={operation==1&&b[31],b[31:16]};
    assign busy=stage!=0;
    wire [15:0] low_cross=p00[31:16]+p01[15:0]+p10[15:0];
    assign ready=stage==3||(EARLY_LOW&&stage==2&&kind==0)||(EARLY_LOW==2&&stage==1&&kind==0);
    assign result=EARLY_LOW==2&&stage==1&&kind==0?{low_cross,p00[15:0]}:
        EARLY_LOW&&kind==0?{cross_sum[15:0],low_base}:answer;
    // Product registers may run continuously: stage 1 consumes the products
    // captured on the start edge. Later changes are dead. Keeping the long
    // interrupt/start control away from DSP clock enables preserves latency,
    // cancellation and backpressure while shortening the physical path.
    generate if(STREAM_PRODUCTS) begin: streaming
        always @(posedge clk) begin
            p00<=a[15:0]*b[15:0];
            p01<=alo*bhi; p10<=ahi*blo; p11<=ahi*bhi;
        end
    end else begin: enabled
        always @(posedge clk) if(!reset&&stage==0&&start) begin
            p00<=a[15:0]*b[15:0];
            p01<=alo*bhi; p10<=ahi*blo; p11<=ahi*bhi;
        end
    end endgenerate
    always @(posedge clk) begin
        if(reset) stage<=0;
        else case(stage)
            0: if(start) begin
                kind<=operation;stage<=1;
            end
            1: begin
                cross_sum<=$signed({p01[33],p01})+$signed({p10[33],p10})+$signed({19'b0,p00[31:16]});
                high_base<=p11[31:0];low_base<=p00[15:0];stage<=EARLY_LOW==2&&kind==0&&consume?0:2;
            end
            2: begin
                if(kind==0) answer<={cross_sum[15:0],low_base};
                else answer<=high_base+{{13{cross_sum[34]}},cross_sum[34:16]};
                stage<=EARLY_LOW&&kind==0&&consume?0:3;
            end
            3: if(consume) stage<=0;
        endcase
    end
endmodule
