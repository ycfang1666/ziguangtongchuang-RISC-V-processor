// Blocking burst adapter for a one-cycle synchronous instruction ROM.
// Read at acceptance, expose the ROM's own registered output, and hold it
// through backpressure. No combinational array reads or array reset.
module rv32_instruction_port #(
    parameter ROM_FILE="firmware.hex", WAIT_CYCLES=0
)(
    input wire clk,reset,
    input wire req_valid, output wire req_ready,
    input wire [31:0] req_address, input wire [2:0] req_beats,
    output wire rsp_valid, input wire rsp_ready,
    output wire [31:0] rsp_data, output reg rsp_error=0,rsp_last=0
);
    reg busy=0,valid=0;
    reg [31:0] address=0;
    reg [2:0] remaining=0;
    reg [15:0] wait_left=0;
    // Retire the final held beat and accept the next transaction on one edge.
    assign req_ready=!reset&&(!busy||(valid&&rsp_ready&&rsp_last));
    assign rsp_valid=!reset&&valid;
    wire accept=req_valid&&req_ready;
    wire consume=rsp_valid&&rsp_ready;
    wire next_beat=consume&&!rsp_last;
    wire read_now=!reset&&((WAIT_CYCLES==0&&(accept||next_beat))||
        (busy&&!valid&&wait_left==1));
    wire [31:0] read_address=accept?req_address:next_beat?address+32'd4:address;
    wire [2:0] read_remaining=accept?req_beats:next_beat?remaining-3'd1:remaining;
    rv32_rom #(.FILE(ROM_FILE)) instruction_rom(
        clk,read_now,read_address[15:2],rsp_data);
    always @(posedge clk) begin
        if(reset) begin
            busy<=0; valid<=0; address<=0; remaining<=0; wait_left<=0;
            rsp_error<=0; rsp_last<=0;
        end else begin
            if(consume) begin
                valid<=0;
                if(rsp_last) busy<=0;
                else begin
                    address<=address+32'd4; remaining<=remaining-3'd1;
                    wait_left<=WAIT_CYCLES;
                end
            end
            // Acceptance owns the next transaction even when the old last
            // response is consumed on this edge (including WAIT_CYCLES>0).
            if(accept) begin
                busy<=1; address<=req_address; remaining<=req_beats;
                wait_left<=WAIT_CYCLES;
            end
            if(busy&&!valid&&wait_left!=0) wait_left<=wait_left-1'b1;
            if(read_now) begin
                valid<=1; rsp_error<=read_address[31:16]!=0;
                rsp_last<=read_remaining==1;
            end
        end
    end
endmodule
