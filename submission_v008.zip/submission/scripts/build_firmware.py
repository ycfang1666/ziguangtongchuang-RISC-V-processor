"""Optional software rebuild; PDS uses the already supplied firmware image."""
import argparse,hashlib,json,re,shutil,struct,subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
def run(args):return subprocess.check_output([str(x) for x in args],text=True)
def image_from_elf(elf):
    data=elf.read_bytes()
    assert data[:6]==b'\x7fELF\x01\x01' and struct.unpack_from('<H',data,18)[0]==243
    offset=struct.unpack_from('<I',data,28)[0];size,count=struct.unpack_from('<HH',data,42)
    image=bytearray(b'\x13\x00\x00\x00'*16384)
    for i in range(count):
        kind,start,virtual,physical,length,memory,flags,align=struct.unpack_from('<8I',data,offset+i*size)
        if kind!=1 or not length:continue
        assert physical+length<=len(image),'ROM overflow'
        image[physical:physical+length]=data[start:start+length]
    return image
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--gcc',required=True,help='Path/name of the RISC-V GCC15.2.0 compiler')
    p.add_argument('--out',type=Path,default=ROOT/'firmware/rebuilt')
    p.add_argument('--verify-included',action='store_true',help='Require all65536 ROM bytes to match the supplied image')
    a=p.parse_args();gcc=shutil.which(a.gcc) or str(Path(a.gcc).resolve())
    version=run([gcc,'-dumpfullversion']).strip()
    if version!='15.2.0':raise SystemExit('Expected GCC15.2.0, got '+version)
    prefix=gcc[:-len('gcc.exe')] if gcc.endswith('gcc.exe') else gcc[:-3]
    out=a.out.resolve();out.mkdir(parents=True,exist_ok=True);obj=out/'obj';obj.mkdir(exist_ok=True)
    flags=['-march=rv32i_zmmul','-mabi=ilp32','-O2','-ffreestanding','-fno-builtin',
           '-fno-unroll-loops','-fno-common','-msmall-data-limit=0','-Wall','-Wextra','-g',
           '-I'+str(ROOT/'firmware/src'),'-I'+str(ROOT/'firmware/coremark'),
           '-DCSR_ENABLE=1','-DCLOCK_HZ=180000000U']
    sources=[ROOT/'firmware/src'/n for n in ['start.S','platform.c','monitor.c','core_portme.c']]
    sources += [ROOT/'firmware/coremark'/n for n in ['core_list_join.c','core_main.c','core_matrix.c','core_state.c','core_util.c']]
    objects=[]
    for source in sources:
        target=obj/(source.stem+'.o');extra=['-Dmain=coremark_entry'] if source.name=='core_main.c' else []
        subprocess.run([gcc,*flags,*extra,'-c',str(source),'-o',str(target)],check=True);objects.append(str(target))
    elf=out/'firmware.elf'
    subprocess.run([gcc,*flags,'-nostdlib','-Wl,--no-relax','-Wl,-Map='+str(out/'firmware.map'),
                    '-T',str(ROOT/'firmware/src/link.ld'),*objects,'-lgcc','-o',str(elf)],check=True)
    dis=run([prefix+'objdump','-d',elf])
    for line in dis.splitlines():
        cols=line.split('\t')
        if len(cols)<3 or not cols[0].strip().endswith(':') or not cols[2].split():continue
        op=cols[2].split()[0]
        assert not op.startswith(('div','rem','amo','lr.','sc.','fadd','fsub','fmul','fdiv','c.')),op
        if op.startswith('mul'):assert op in ['mul','mulh','mulhsu','mulhu'],op
    (out/'firmware.dis').write_text(dis,encoding='utf-8')
    image=image_from_elf(elf)
    hex_text=''.join(f'{struct.unpack_from("<I",image,i)[0]:08x}\n' for i in range(0,len(image),4))
    (out/'firmware.hex').write_text(hex_text,encoding='ascii')
    match=(ROOT/'firmware/firmware.hex').read_text(encoding='ascii')==hex_text
    record=dict(compiler_version=version,flags=flags,rom_bytes=len(image),
                rom_sha256=hashlib.sha256(image).hexdigest(),matches_included_rom=match)
    (out/'build.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    if a.verify_included:assert match,'Rebuilt ROM differs from the supplied v008 image'
    print('FIRMWARE_REBUILD: PASS; matches included ROM =',match)
if __name__=='__main__':main()
