#include "platform.h"
#include <stdarg.h>
#ifndef UART_PACE_DEFAULT_MS
#define UART_PACE_DEFAULT_MS 250U
#endif
#define OUTPUT_BYTES 2048U
#define OUTPUT_CHUNK 24U
static char output[OUTPUT_BYTES];
static unsigned output_length;
static char report[OUTPUT_BYTES];
static unsigned report_length,report_overflow,capture;
static unsigned pace_ms=UART_PACE_DEFAULT_MS;
static char previous;
static unsigned compact_coremark;
void uart_coremark_compact(unsigned enabled) { compact_coremark=enabled; }
static int prefix(const char *text,const char *start) {
    while(*start) if(*text++!=*start++)return 0;
    return 1;
}
uint64_t ticks(void) {
    uint32_t high,low,again;
    do { high=TIMER_HI; low=TIMER_LO; again=TIMER_HI; } while(high!=again);
    return ((uint64_t)high<<32)|low;
}
static void quiet(void) {
    while(UART_STATUS&0x20U) {}
    uint64_t start=ticks();
    uint32_t wait_ticks=pace_ms*(CLOCK_HZ/1000U);
    while(ticks()-start<wait_ticks) {}
}
void uart_flush(void) {
    if(!output_length)return;
    unsigned burst=0;
    // Every response uses the same buffered path, including startup and prompts.
    quiet();
    for(unsigned i=0;i<output_length;++i) {
        char c=output[i];UART_TX=(uint8_t)c;
        if(++burst>=OUTPUT_CHUNK || c=='\n') {quiet();burst=0;}
    }
    if(burst)quiet();
    output_length=0;
}
static void append(char c) {
    if(capture) {
        if(report_length<OUTPUT_BYTES)report[report_length++]=c;
        else report_overflow=1;
    }
    // Large messages drain in bounded blocks rather than dropping bytes.
    if(output_length==OUTPUT_BYTES)uart_flush();
    output[output_length++]=c;
}
void putchar_uart(char c) {
    if(c=='\n' && previous!='\r') append('\r');
    append(c); previous=c;
}
void puts_uart(const char *s) { while(*s) putchar_uart(*s++); }
void uart_set_pace(unsigned ms) { uart_flush();pace_ms=ms; }
unsigned uart_get_pace(void) { return pace_ms; }
void uart_report_begin(void) { report_length=0;report_overflow=0;capture=1; }
void uart_report_end(void) {
    capture=0;
    if(report_overflow)puts_uart("ERROR saved result truncated\r\n");
}
void uart_report_replay(unsigned page) {
    if(!report_length) {puts_uart("ERROR no saved result\r\n");return;}
    unsigned pages=(report_length+OUTPUT_CHUNK-1)/OUTPUT_CHUNK;
    if(page>pages) {puts_uart("ERROR result page\r\n");return;}
    if(page)ee_printf("PAGE %u/%u\r\n",page,pages);
    else puts_uart("RESULT BEGIN\r\n");
    unsigned first=page?(page-1)*OUTPUT_CHUNK:0;
    unsigned end=page?first+OUTPUT_CHUNK:report_length;
    if(end>report_length)end=report_length;
    for(unsigned i=first;i<end;++i)putchar_uart(report[i]);
    if(previous!='\n')puts_uart("\r\n");
    if(!page)puts_uart("RESULT END\r\n");
    if(report_overflow)puts_uart("ERROR saved result truncated\r\n");
}
static void number(uint32_t value,unsigned base,int sign) {
    char out[32]; unsigned n=0;
    if(sign&&(int32_t)value<0) { putchar_uart('-'); value=0-value; }
    do { unsigned digit=value%base; out[n++]=digit<10?'0'+digit:'a'+digit-10; value/=base; } while(value);
    while(n) putchar_uart(out[--n]);
}
int ee_printf(const char *format, ...) {
    va_list args; va_start(args,format);
    // Presentation only: upstream CoreMark algorithms, timing and validation
    // are unchanged. Never filter unknown output or diagnostics.
    if(compact_coremark) {
        if(prefix(format,"2K performance run parameters") || prefix(format,"CoreMark Size") ||
           prefix(format,"Total ticks") || prefix(format,"Total time") ||
           prefix(format,"Iterations/Sec") || prefix(format,"Compiler version") ||
           prefix(format,"Compiler flags") || prefix(format,"Memory location")) {
            va_end(args); return 0;
        }
        if(prefix(format,"seedcrc")) format="CRC seed=0x%x ";
        else if(prefix(format,"[%d]crc")) {
            // Single context is fixed by this port. Consume its original index.
            (void)va_arg(args,int);
            if(prefix(format,"[%d]crclist"))format="list=0x%x ";
            else if(prefix(format,"[%d]crcmatrix"))format="matrix=0x%x ";
            else if(prefix(format,"[%d]crcstate"))format="state=0x%x ";
            else format="final=0x%x\n";
        }
        else if(prefix(format,"Correct operation validated."))format="Correct operation validated\n";
    }
    while(*format) {
        if(*format!='%') { putchar_uart(*format++); continue; }
        ++format;
        // CoreMark widths are presentation only. All required integer/string types are supported.
        while(*format=='-'||*format=='0'||(*format>='0'&&*format<='9')) ++format;
        if(*format=='l') ++format;
        switch(*format++) {
            case 's': puts_uart(va_arg(args,const char *)); break;
            case 'd': case 'i': number(va_arg(args,unsigned),10,1); break;
            case 'u': number(va_arg(args,unsigned),10,0); break;
            case 'x': case 'X': number(va_arg(args,unsigned),16,0); break;
            case 'c': putchar_uart((char)va_arg(args,int)); break;
            case '%': putchar_uart('%'); break;
            default: puts_uart("FORMAT_ERROR"); break;
        }
    }
    va_end(args); return 0;
}
void *memcpy(void *dest,const void *src,size_t size) {
    unsigned char *d=dest; const unsigned char *s=src; while(size--) *d++=*s++; return dest;
}
void *memset(void *dest,int c,size_t size) {
    unsigned char *d=dest; while(size--) *d++=(unsigned char)c; return dest;
}
