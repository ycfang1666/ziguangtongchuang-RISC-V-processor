#include "coremark.h"
#ifndef COREMARK_SHORT
#define COREMARK_SHORT 0
#endif
volatile ee_s32 seed1_volatile=0,seed2_volatile=0,seed3_volatile=0x66;
volatile ee_s32 seed4_volatile=COREMARK_SHORT?1:0;
volatile ee_s32 seed5_volatile=0;
ee_u32 default_num_contexts=1;
static CORE_TICKS start,stop;
// Offset zero is a read-trigger: its returned time and the entire frozen bank
// come from the same edge. Reading the bank cannot tear a 64-bit counter.
// The start-bank reads are inside the measured interval; UART/reporting is not.
typedef struct { uint64_t time,cycles,retired; uint32_t event[9]; } profile_sample;
static profile_sample before,after;
static void sample(profile_sample *p) {
    uint32_t lo=MMIO(0x20002100);
    p->time=((uint64_t)MMIO(0x20002104)<<32)|lo;
    lo=MMIO(0x20002108);
    p->cycles=((uint64_t)MMIO(0x2000210c)<<32)|lo;
    lo=MMIO(0x20002110);
    p->retired=((uint64_t)MMIO(0x20002114)<<32)|lo;
    for(unsigned n=0;n<9;n++) p->event[n]=MMIO(0x20002118+4*n);
}
void start_time(void) { sample(&before); start=before.time; }
void stop_time(void) { sample(&after); stop=after.time; }
CORE_TICKS get_time(void) { return stop-start; }
secs_ret time_in_secs(CORE_TICKS value) { return (secs_ret)(value/CLOCK_HZ); }
void portable_init(core_portable *p,int *argc,char *argv[]) { (void)argc;(void)argv; p->portable_id=1; }
void portable_fini(core_portable *p) {
    p->portable_id=0;
    uint64_t elapsed=get_time();
    ee_printf("MEASURE ticks_hi=%u ticks_lo=%u hz=%u short=%u version=v008\r\n",
        (uint32_t)(elapsed>>32),(uint32_t)elapsed,CLOCK_HZ,COREMARK_SHORT);
    uint64_t retired=after.retired-before.retired;
    // PROFILE v2 uses the identical atomic timer/cycle window in MEASURE.
    ee_printf("PROFILE v=2 retired_hi=%u retired_lo=%u\r\n",(uint32_t)(retired>>32),(uint32_t)retired);
    ee_printf("PROFILE branch=%u mispredict=%u ex_stall=%u\r\n",
        after.event[0]-before.event[0],after.event[1]-before.event[1],after.event[2]-before.event[2]);
    unsigned cache=MMIO(0x20002050);
    if(cache)ee_printf("CACHE i=%u d=%u ihit=%u imiss=%u dhit=%u dmiss=%u\r\n",
        cache&1,(cache>>1)&1,after.event[3]-before.event[3],after.event[4]-before.event[4],
        after.event[5]-before.event[5],after.event[6]-before.event[6]);
    else puts_uart("CACHE i=0 d=0\r\n");
    ee_printf("PROFILE if_wait=%u data_wait=%u\r\n",
        after.event[7]-before.event[7],after.event[8]-before.event[8]);
}
extern int coremark_entry(void);
void coremark_run(void) {
    uart_report_begin();
    puts_uart(COREMARK_SHORT?"COREMARK CRC TEST ONLY\r\n":"COREMARK START (automatic iterations, >=10s)\r\n");
    uart_flush();
    uart_coremark_compact(1);
    coremark_entry();
    uart_coremark_compact(0);
    puts_uart("COREMARK DONE\r\n");
    uart_report_end();
    uart_flush();
}
