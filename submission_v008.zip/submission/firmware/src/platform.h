#ifndef PLATFORM_H
#define PLATFORM_H
#include <stdint.h>
#include <stddef.h>
#define MMIO(a) (*(volatile uint32_t *)(uintptr_t)(a))
#define UART_TX MMIO(0x20000000)
#define UART_STATUS MMIO(0x20000004)
#define UART_RX MMIO(0x20000008)
#define UART_CONTROL MMIO(0x2000000c)
#define LED MMIO(0x20001000)
#define TIMER_LO MMIO(0x20002000)
#define TIMER_HI MMIO(0x20002004)
#define COMPARE_LO MMIO(0x20002008)
#define COMPARE_HI MMIO(0x2000200c)
#define SOFT_IRQ MMIO(0x20002010)
#ifndef CLOCK_HZ
#define CLOCK_HZ 36000000U
#endif
uint64_t ticks(void);
void putchar_uart(char c);
void puts_uart(const char *s);
int ee_printf(const char *format, ...);
void coremark_run(void);
void uart_set_pace(unsigned ms);
unsigned uart_get_pace(void);
void uart_flush(void);
void uart_report_begin(void);
void uart_report_end(void);
void uart_report_replay(unsigned page);
void uart_coremark_compact(unsigned enabled);
#endif
