#ifndef CORE_PORTME_H
#define CORE_PORTME_H
#include "platform.h"
#define HAS_FLOAT 0
#define HAS_TIME_H 0
#define HAS_STDIO 0
#define HAS_PRINTF 0
#define MAIN_HAS_NOARGC 1
#define MAIN_HAS_NORETURN 0
#define SEED_METHOD SEED_VOLATILE
#define MEM_METHOD MEM_STATIC
#define MULTITHREAD 1
#define COMPILER_VERSION __VERSION__
#ifdef __riscv_zmmul
#define COMPILER_FLAGS "-O2 -march=rv32i_zmmul -mabi=ilp32 -fno-builtin -fno-unroll-loops"
#else
#define COMPILER_FLAGS "-O2 -march=rv32i -mabi=ilp32 -fno-builtin -fno-unroll-loops"
#endif
#define MEM_LOCATION "code=64KiB on-chip ROM,data=64KiB on-chip RAM; memory:CPU=1:1"
#define PERFORMANCE_RUN 1
#define VALIDATION_RUN 0
#define PROFILE_RUN 0
typedef int16_t ee_s16;
typedef uint16_t ee_u16;
typedef int32_t ee_s32;
typedef uint32_t ee_u32;
typedef uint8_t ee_u8;
typedef uintptr_t ee_ptr_int;
typedef size_t ee_size_t;
typedef uint64_t CORE_TICKS;
#define align_mem(x) ((void *)(((ee_ptr_int)(x)+3)&~(ee_ptr_int)3))
typedef struct { ee_u8 portable_id; } core_portable;
extern ee_u32 default_num_contexts;
void portable_init(core_portable *p,int *argc,char *argv[]);
void portable_fini(core_portable *p);
#endif
