#include "platform.h"
#ifndef CSR_ENABLE
#define CSR_ENABLE 1
#endif
#ifndef SIM_TEST
#define SIM_TEST 0
#endif
#ifndef SIM_COREMARK
#define SIM_COREMARK 0
#endif
static volatile uint32_t traps, interrupts, expected_cause=0xffffffffU, trap_fail;
// Volatile prevents GCC from replacing startup-memory checks with constants.
static volatile uint32_t initialized_data=0x12345678;
static volatile uint32_t uninitialized_data;
#define CSR_READ(csr,out) __asm__ volatile(".option push\n.option arch,+zicsr\ncsrr %0," #csr "\n.option pop":"=r"(out))
#define CSR_WRITE(csr,in) __asm__ volatile(".option push\n.option arch,+zicsr\ncsrw " #csr ",%0\n.option pop"::"r"(in):"memory")
extern void trap_entry(void);
void trap_handler(void) {
#if CSR_ENABLE
    uint32_t cause,pc;
    CSR_READ(mcause,cause); CSR_READ(mepc,pc);
    if(cause&0x80000000U) {
        ++interrupts;
        if(cause==0x80000003U) SOFT_IRQ=0;
        else if(cause==0x80000007U) { COMPARE_HI=0xffffffffU; COMPARE_LO=0xffffffffU; }
        else if(cause==0x8000000bU) UART_CONTROL=0;
        else trap_fail=1;
    } else {
        ++traps;
        if(cause!=expected_cause) trap_fail=1;
        CSR_WRITE(mepc,pc+4);
    }
#endif
}
static int equal(const char *a,const char *b) { while(*a&&*a==*b) { ++a;++b; } return *a==*b; }
static int argument(const char *line,const char *prefix,unsigned *value) {
    while(*prefix)if(*line++!=*prefix++)return 0;
    if(!*line)return 0;
    unsigned n=0;
    while(*line) {
        if(*line<'0'||*line>'9')return 0;
        n=n*10+(unsigned)(*line++-'0');if(n>1000)return 0;
    }
    *value=n;return 1;
}
static int selftest(void) {
    volatile uint32_t words[8]; unsigned i;
    int pass=initialized_data==0x12345678 && uninitialized_data==0;
    for(i=0;i<8;i++) words[i]=0xa5a50000U+i;
    for(i=0;i<8;i++) if(words[i]!=0xa5a50000U+i) pass=0;
    volatile uint8_t *bytes=(volatile uint8_t *)words;
    bytes[1]=0x80;
    if(words[0]!=0xa5a58000U || ((volatile int8_t *)words)[1]!=-128) pass=0;
    volatile uint16_t *halves=(volatile uint16_t *)words;
    halves[1]=0xbeef;
    if(words[0]!=0xbeef8000U) pass=0;
#if CSR_ENABLE
    uint32_t before=traps;
    expected_cause=11; __asm__ volatile("ecall":::"memory");
    expected_cause=3; __asm__ volatile("ebreak":::"memory");
    expected_cause=2; __asm__ volatile(".word 0xffffffff":::"memory");
    expected_cause=4; __asm__ volatile("lw zero,1(%0)"::"r"(words):"memory");
    expected_cause=6; __asm__ volatile("sw zero,1(%0)"::"r"(words):"memory");
    expected_cause=5; __asm__ volatile("lw zero,0(%0)"::"r"(0x30000000U):"memory");
    expected_cause=7; __asm__ volatile("sw zero,0(%0)"::"r"(0x30000000U):"memory");
    expected_cause=0; __asm__ volatile("jalr zero,0(%0)"::"r"(2):"memory");
    if(traps-before!=8) pass=0;
    uint32_t interrupts_before=interrupts;
    CSR_WRITE(mie,0x88); CSR_WRITE(mstatus,8);
    SOFT_IRQ=1;
    for(i=0;i<1000 && interrupts==interrupts_before;i++) __asm__ volatile("nop");
    if(interrupts!=interrupts_before+1) pass=0;
    uint64_t deadline=ticks()+2000;
    COMPARE_HI=0xffffffffU; COMPARE_LO=(uint32_t)deadline; COMPARE_HI=(uint32_t)(deadline>>32);
    for(i=0;i<10000 && interrupts==interrupts_before+1;i++) __asm__ volatile("nop");
    CSR_WRITE(mstatus,0); CSR_WRITE(mie,0);
    if(interrupts!=interrupts_before+2 || trap_fail) pass=0;
    if(SIM_TEST) {
        interrupts_before=interrupts;
        UART_CONTROL=2; CSR_WRITE(mie,0x800); CSR_WRITE(mstatus,8);
        puts_uart("IRQ RX READY\r\n");
        uart_flush();
        while(interrupts==interrupts_before) __asm__ volatile("nop");
        CSR_WRITE(mstatus,0); CSR_WRITE(mie,0);
        if(interrupts!=interrupts_before+1 || UART_RX!='Z' || trap_fail) pass=0;
    }
#endif
    puts_uart(pass?"SELFTEST PASS\r\n":"SELFTEST FAIL\r\n"); return pass;
}
static void stats(void) {
    for(uint32_t off=0x20;off<=0x4c;off+=4) {
        if(off==0x3c)continue; // Reserved address, not a readable performance counter.
        ee_printf("STAT %x=%u\r\n",off,MMIO(0x20002000+off));
    }
}
int main(void) {
#if CSR_ENABLE
    CSR_WRITE(mtvec,(uint32_t)(uintptr_t)trap_entry);
#endif
    uart_report_begin();puts_uart("RV32 CPU READY\r\n");
    puts_uart("VERSION v008\r\n");ee_printf("PLL CPU hz=%u UART=115200\r\n",CLOCK_HZ);uart_report_end();uart_flush();
    if(SIM_COREMARK) { coremark_run(); puts_uart("SIM DONE\r\n");uart_flush(); for(;;) __asm__ volatile("nop"); }
    if(SIM_TEST) { selftest(); puts_uart("SIM DONE\r\n");uart_flush(); for(;;) __asm__ volatile("nop"); }
    char line[48]; unsigned length=0; int discard=0;
    puts_uart("Commands: help, led 0, led 1, time, selftest, stats, coremark, pace [N], result [N]\r\n> ");uart_flush();
    for(;;) {
        if(!(UART_STATUS&0x40)) continue;
        char c=(char)UART_RX;
        if(c=='\r') continue;
        if(c!='\n') { if(length+1<sizeof line) line[length++]=c; else discard=1; continue; }
        line[length]=0;
        unsigned arg=0;
        if(discard) puts_uart("ERROR line too long\r\n");
        else if(equal(line,"help")) puts_uart("help | led 0 | led 1 | time | selftest | stats | coremark | pace [N] | result [N]\r\n");
        else if(equal(line,"led 0")) { LED=0; puts_uart("LED 0\r\n"); }
        else if(equal(line,"led 1")) { LED=1; puts_uart("LED 1\r\n"); }
        else if(equal(line,"time")) ee_printf("TIME ticks_hi=%u ticks_lo=%u hz=%u\r\n",TIMER_HI,TIMER_LO,CLOCK_HZ);
        else if(equal(line,"selftest")) selftest();
        else if(equal(line,"stats")) stats();
        else if(equal(line,"coremark")) coremark_run();
        else if(equal(line,"pace")) ee_printf("PACE ms=%u bytes=24\r\n",uart_get_pace());
        else if(equal(line,"result")) uart_report_replay(0);
        else if(argument(line,"result ",&arg) && arg) uart_report_replay(arg);
        else if(argument(line,"pace ",&arg)) { uart_set_pace(arg);ee_printf("PACE ms=%u bytes=24\r\n",arg); }
        else puts_uart("ERROR unknown command\r\n");
        length=0; discard=0; puts_uart("> ");uart_flush();
    }
}
